import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { VoxelWorld, WORLD_HEIGHT } from '../src/world.js';
import { BLOCK } from '../src/data.js';

test('voxel world generates deterministic terrain, meshes, and sparse edits', () => {
  const sceneA = new THREE.Scene();
  const sceneB = new THREE.Scene();
  const worldA = new VoxelWorld(123456, sceneA);
  const worldB = new VoxelWorld(123456, sceneB);

  const samples = [[0,10,0],[8,16,-7],[-13,4,22],[31,24,31]];
  for (const [x, y, z] of samples) {
    assert.equal(worldA.getBlock(x, y, z, 'verdant'), worldB.getBlock(x, y, z, 'verdant'));
    assert.equal(worldA.getBlock(x, y, z, 'ember'), worldB.getBlock(x, y, z, 'ember'));
    assert.equal(worldA.getBlock(x, y, z, 'astral'), worldB.getBlock(x, y, z, 'astral'));
  }

  const emberFloor = worldA.highestSolid(0, 0, 'ember');
  assert.ok(emberFloor > 0 && emberFloor < 24, `expected cavern floor, got ${emberFloor}`);

  worldA.setDimension('verdant');
  worldA.updateVisibleChunks(0, 0, 1);
  while (worldA.processBuildQueue(2)) {}
  const chunk = worldA.ensureChunk(0, 0, 'verdant');
  assert.ok(chunk.group);
  assert.ok(chunk.group.children.length > 0);
  const vertexCount = chunk.group.children.reduce(
    (sum, mesh) => sum + (mesh.geometry?.getAttribute('position')?.count ?? 0), 0
  );
  assert.ok(vertexCount > 0);

  const y = Math.min(WORLD_HEIGHT - 2, worldA.highestSolid(2, 2, 'verdant') + 1);
  worldA.setBlock(2, y, 2, BLOCK.BRICK, 'verdant');
  assert.equal(worldA.getBlock(2, y, 2, 'verdant'), BLOCK.BRICK);
  const exported = worldA.exportEdits();
  assert.ok(exported.verdant.some(([key, id]) => key === `2,${y},2` && id === BLOCK.BRICK));

  worldA.clear();
  worldB.clear();
});
