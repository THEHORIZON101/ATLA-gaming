
import test from 'node:test';
import assert from 'node:assert/strict';
import { seedFromString, fbm2, hash3 } from '../src/noise.js';
import { RECIPES, ITEMS, canCraft, craftRecipe } from '../src/data.js';

test('seed generation is deterministic and differentiates common inputs', () => {
  assert.equal(seedFromString('wild-horizon'), seedFromString('wild-horizon'));
  assert.notEqual(seedFromString('wild-horizon'), seedFromString('wild-horizons'));
});

test('noise helpers are deterministic and bounded', () => {
  const a = fbm2(1.25, -4.5, 1234, 5);
  const b = fbm2(1.25, -4.5, 1234, 5);
  assert.equal(a, b);
  assert.ok(a >= -1 && a <= 1);
  const h = hash3(1, 2, 3, 99);
  assert.ok(h >= 0 && h < 1);
});

test('all recipes reference defined items and have positive quantities', () => {
  const ids = new Set();
  for (const recipe of RECIPES) {
    assert.ok(!ids.has(recipe.id), `duplicate recipe id ${recipe.id}`);
    ids.add(recipe.id);
    const [out, count] = recipe.out;
    assert.ok(ITEMS[out], `undefined output ${out}`);
    assert.ok(count > 0);
    for (const [id, needed] of Object.entries(recipe.in)) {
      assert.ok(ITEMS[id], `undefined ingredient ${id}`);
      assert.ok(needed > 0);
    }
  }
});

test('crafting consumes inputs and creates output', () => {
  const recipe = RECIPES.find(r => r.id === 'boards');
  const inventory = { 'block:log': 2 };
  assert.equal(canCraft(recipe, inventory, () => true), true);
  assert.equal(craftRecipe(recipe, inventory), true);
  assert.equal(inventory['block:log'], 1);
  assert.equal(inventory['block:planks'], 4);
});

test('station restrictions are enforced', () => {
  const recipe = RECIPES.find(r => r.id === 'iron_pick');
  const inventory = { iron_ingot: 3, stick: 2 };
  assert.equal(canCraft(recipe, inventory, station => station === 'hand'), false);
  assert.equal(canCraft(recipe, inventory, station => station === 'bench'), true);
});
