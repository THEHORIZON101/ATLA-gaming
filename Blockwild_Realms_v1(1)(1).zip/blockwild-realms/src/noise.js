
function fract(n) { return n - Math.floor(n); }

export function hash2(x, z, seed = 0) {
  const n = Math.sin(x * 127.1 + z * 311.7 + seed * 74.7) * 43758.5453123;
  return fract(n);
}

export function hash3(x, y, z, seed = 0) {
  const n = Math.sin(x * 157.7 + y * 113.5 + z * 271.9 + seed * 61.3) * 43758.5453123;
  return fract(n);
}

function smooth(t) { return t * t * (3 - 2 * t); }
function lerp(a, b, t) { return a + (b - a) * t; }

export function valueNoise2(x, z, seed = 0) {
  const xi = Math.floor(x), zi = Math.floor(z);
  const xf = x - xi, zf = z - zi;
  const u = smooth(xf), v = smooth(zf);
  const a = hash2(xi, zi, seed) * 2 - 1;
  const b = hash2(xi + 1, zi, seed) * 2 - 1;
  const c = hash2(xi, zi + 1, seed) * 2 - 1;
  const d = hash2(xi + 1, zi + 1, seed) * 2 - 1;
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function valueNoise3(x, y, z, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = smooth(x - xi), yf = smooth(y - yi), zf = smooth(z - zi);
  const h = (dx, dy, dz) => hash3(xi + dx, yi + dy, zi + dz, seed) * 2 - 1;
  const x00 = lerp(h(0,0,0), h(1,0,0), xf);
  const x10 = lerp(h(0,1,0), h(1,1,0), xf);
  const x01 = lerp(h(0,0,1), h(1,0,1), xf);
  const x11 = lerp(h(0,1,1), h(1,1,1), xf);
  return lerp(lerp(x00, x10, yf), lerp(x01, x11, yf), zf);
}

export function fbm2(x, z, seed = 0, octaves = 4) {
  let total = 0, amplitude = 0.5, frequency = 1, norm = 0;
  for (let i = 0; i < octaves; i++) {
    total += valueNoise2(x * frequency, z * frequency, seed + i * 17) * amplitude;
    norm += amplitude;
    amplitude *= 0.5;
    frequency *= 2.03;
  }
  return total / norm;
}

export function fbm3(x, y, z, seed = 0, octaves = 3) {
  let total = 0, amplitude = 0.5, frequency = 1, norm = 0;
  for (let i = 0; i < octaves; i++) {
    total += valueNoise3(x * frequency, y * frequency, z * frequency, seed + i * 19) * amplitude;
    norm += amplitude;
    amplitude *= 0.5;
    frequency *= 2.01;
  }
  return total / norm;
}

export function seedFromString(value) {
  let h = 2166136261 >>> 0;
  for (const ch of String(value)) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
