
import * as THREE from 'three';
import { BLOCK, BLOCKS } from './data.js';
import { fbm2, fbm3, hash2, hash3 } from './noise.js';

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 48;

const FACE_DEFS = [
  { dir: [ 1, 0, 0], shade: 0.82, corners: [[1,0,0],[1,1,0],[1,1,1],[1,0,1]] },
  { dir: [-1, 0, 0], shade: 0.72, corners: [[0,0,1],[0,1,1],[0,1,0],[0,0,0]] },
  { dir: [ 0, 1, 0], shade: 1.00, corners: [[0,1,1],[1,1,1],[1,1,0],[0,1,0]] },
  { dir: [ 0,-1, 0], shade: 0.55, corners: [[0,0,0],[1,0,0],[1,0,1],[0,0,1]] },
  { dir: [ 0, 0, 1], shade: 0.90, corners: [[1,0,1],[1,1,1],[0,1,1],[0,0,1]] },
  { dir: [ 0, 0,-1], shade: 0.76, corners: [[0,0,0],[0,1,0],[1,1,0],[1,0,0]] }
];

function floorDiv(n, d) {
  return Math.floor(n / d);
}

function indexOf(lx, y, lz) {
  return lx + lz * CHUNK_SIZE + y * CHUNK_SIZE * CHUNK_SIZE;
}

function key3(x, y, z) {
  return `${x},${y},${z}`;
}

function chunkKey(cx, cz) {
  return `${cx},${cz}`;
}

function colorForFace(block, faceIndex, x, y, z, seed) {
  let base = block.color;
  if (faceIndex === 2 && block.topColor) base = block.topColor;
  if (faceIndex !== 2 && faceIndex !== 3 && block.sideColor) base = block.sideColor;
  if (block.fleck && hash3(x, y, z, seed + faceIndex * 101) > 0.73) base = block.fleck;
  const c = new THREE.Color(base);
  const jitter = 0.91 + hash3(x, y, z, seed + faceIndex * 37) * 0.13;
  c.multiplyScalar(FACE_DEFS[faceIndex].shade * jitter);
  return c;
}

export class VoxelWorld {
  constructor(seed, scene) {
    this.seed = seed >>> 0;
    this.scene = scene;
    this.dimension = 'verdant';
    this.dimensions = {
      verdant: { chunks: new Map(), edits: new Map(), group: new THREE.Group() },
      ember: { chunks: new Map(), edits: new Map(), group: new THREE.Group() },
      astral: { chunks: new Map(), edits: new Map(), group: new THREE.Group() }
    };
    Object.entries(this.dimensions).forEach(([name, state]) => {
      state.group.name = `dimension-${name}`;
      state.group.visible = name === this.dimension;
      this.scene.add(state.group);
    });
    this.opaqueMaterial = new THREE.MeshLambertMaterial({
      vertexColors: true,
      flatShading: true
    });
    this.transparentMaterial = new THREE.MeshLambertMaterial({
      vertexColors: true,
      flatShading: true,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
      side: THREE.DoubleSide
    });
    this.buildQueue = [];
    this.queued = new Set();
    this.lastCenter = null;
  }

  setDimension(name) {
    if (!this.dimensions[name]) return;
    this.dimension = name;
    for (const [key, state] of Object.entries(this.dimensions)) {
      state.group.visible = key === name;
    }
    this.lastCenter = null;
    this.buildQueue.length = 0;
    this.queued.clear();
  }

  get state() {
    return this.dimensions[this.dimension];
  }

  ensureChunk(cx, cz, dimension = this.dimension) {
    const state = this.dimensions[dimension];
    const key = chunkKey(cx, cz);
    let chunk = state.chunks.get(key);
    if (chunk) return chunk;
    chunk = {
      cx, cz,
      data: new Uint8Array(CHUNK_SIZE * WORLD_HEIGHT * CHUNK_SIZE),
      group: null,
      dirty: true
    };
    this.generateChunk(chunk, dimension);
    state.chunks.set(key, chunk);
    return chunk;
  }

  generateChunk(chunk, dimension) {
    const { cx, cz, data } = chunk;
    const sx = cx * CHUNK_SIZE;
    const sz = cz * CHUNK_SIZE;

    for (let lx = 0; lx < CHUNK_SIZE; lx++) {
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const x = sx + lx;
        const z = sz + lz;
        for (let y = 0; y < WORLD_HEIGHT; y++) {
          data[indexOf(lx, y, lz)] = this.generatedBlockAt(dimension, x, y, z);
        }
      }
    }

    if (dimension === 'verdant') {
      this.decorateVerdant(chunk);
    } else if (dimension === 'ember') {
      this.decorateEmber(chunk);
    } else {
      this.decorateAstral(chunk);
    }

    const state = this.dimensions[dimension];
    for (const [pos, id] of state.edits.entries()) {
      const [x, y, z] = pos.split(',').map(Number);
      if (floorDiv(x, CHUNK_SIZE) === cx && floorDiv(z, CHUNK_SIZE) === cz && y >= 0 && y < WORLD_HEIGHT) {
        const lx = ((x % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        const lz = ((z % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
        data[indexOf(lx, y, lz)] = id;
      }
    }
  }

  terrainHeight(dimension, x, z) {
    if (dimension === 'verdant') {
      const broad = fbm2(x * 0.018, z * 0.018, this.seed + 11, 5);
      const detail = fbm2(x * 0.065, z * 0.065, this.seed + 29, 3);
      return Math.max(5, Math.min(32, Math.round(15 + broad * 9 + detail * 3)));
    }
    if (dimension === 'ember') {
      return Math.max(5, Math.min(16, Math.round(9 + fbm2(x * 0.045, z * 0.045, this.seed + 201, 4) * 5)));
    }
    return Math.round(25 + fbm2(x * 0.035, z * 0.035, this.seed + 401, 4) * 4);
  }

  generatedBlockAt(dimension, x, y, z) {
    if (y < 0 || y >= WORLD_HEIGHT) return BLOCK.AIR;
    if (dimension === 'verdant') return this.generatedVerdant(x, y, z);
    if (dimension === 'ember') return this.generatedEmber(x, y, z);
    return this.generatedAstral(x, y, z);
  }

  generatedVerdant(x, y, z) {
    const h = this.terrainHeight('verdant', x, z);
    const sea = 14;
    const climate = fbm2(x * 0.009 + 90, z * 0.009 - 50, this.seed + 71, 3);

    if (y > h) {
      if (y <= sea) return BLOCK.WATER;
      return BLOCK.AIR;
    }

    if (y === 0) return BLOCK.BASALT;
    if (y === h) {
      if (h <= sea + 1) return BLOCK.SAND;
      if (climate < -0.45 && h > 18) return BLOCK.SNOW;
      return BLOCK.TURF;
    }
    if (y > h - 3) return h <= sea + 1 ? BLOCK.SAND : BLOCK.LOAM;

    const cave = fbm3(x * 0.075, y * 0.085, z * 0.075, this.seed + 99, 3);
    if (y > 3 && y < h - 3 && cave > 0.61) return BLOCK.AIR;

    const roll = hash3(x, y, z, this.seed + 130);
    if (y < 8 && roll > 0.986) return BLOCK.CRYSTAL_ORE;
    if (y < 16 && roll > 0.968) return BLOCK.IRON_ORE;
    if (y < 23 && roll > 0.947) return BLOCK.COPPER_ORE;
    if (y < 30 && roll > 0.925) return BLOCK.COAL_ORE;
    return BLOCK.STONE;
  }

  generatedEmber(x, y, z) {
    const floor = this.terrainHeight('ember', x, z);
    const ceiling = 39 - Math.round(fbm2(x * 0.04, z * 0.04, this.seed + 221, 4) * 4);

    if (y <= floor) {
      if (y <= 1) return BLOCK.BASALT;
      if (y === floor) return BLOCK.ASH;
      const roll = hash3(x, y, z, this.seed + 250);
      if (y < 8 && roll > 0.972) return BLOCK.CRYSTAL_ORE;
      if (roll > 0.94) return BLOCK.COAL_ORE;
      return hash3(x, y, z, this.seed + 261) > 0.55 ? BLOCK.EMBERSTONE : BLOCK.BASALT;
    }
    if (y >= ceiling) {
      const cave = fbm3(x * 0.08, y * 0.08, z * 0.08, this.seed + 280, 3);
      if (cave > 0.69 && y < WORLD_HEIGHT - 2) return BLOCK.AIR;
      return hash3(x, y, z, this.seed + 271) > 0.78 ? BLOCK.EMBERSTONE : BLOCK.BASALT;
    }
    if (y <= 7 && fbm2(x * 0.06, z * 0.06, this.seed + 291, 3) < -0.20) return BLOCK.LAVA;
    return BLOCK.AIR;
  }

  generatedAstral(x, y, z) {
    const radialBoost = Math.max(0, 1 - Math.hypot(x, z) / 24) * 0.6;
    const mask = fbm2(x * 0.026, z * 0.026, this.seed + 421, 5) + radialBoost;
    if (mask < -0.08) return BLOCK.AIR;

    const top = this.terrainHeight('astral', x, z);
    const thickness = Math.round(4 + Math.max(0, mask + 0.2) * 7 + fbm2(x * 0.09, z * 0.09, this.seed + 441, 2) * 2);
    if (y > top || y < top - thickness) return BLOCK.AIR;

    if (y === top) return hash2(x, z, this.seed + 451) > 0.72 ? BLOCK.CLOUDSTONE : BLOCK.STARSTONE;
    const roll = hash3(x, y, z, this.seed + 461);
    if (roll > 0.965) return BLOCK.CRYSTAL_ORE;
    if (roll > 0.91) return BLOCK.VOIDGLASS;
    return BLOCK.STARSTONE;
  }

  setLocal(chunk, x, y, z, id) {
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;
    const lx = x - sx;
    const lz = z - sz;
    if (lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE || y < 0 || y >= WORLD_HEIGHT) return;
    chunk.data[indexOf(lx, y, lz)] = id;
  }

  localBlock(chunk, x, y, z) {
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;
    const lx = x - sx;
    const lz = z - sz;
    if (lx < 0 || lx >= CHUNK_SIZE || lz < 0 || lz >= CHUNK_SIZE || y < 0 || y >= WORLD_HEIGHT) return BLOCK.AIR;
    return chunk.data[indexOf(lx, y, lz)];
  }

  decorateVerdant(chunk) {
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;

    for (let x = sx - 3; x < sx + CHUNK_SIZE + 3; x++) {
      for (let z = sz - 3; z < sz + CHUNK_SIZE + 3; z++) {
        const h = this.terrainHeight('verdant', x, z);
        const top = this.generatedVerdant(x, h, z);
        const treeRoll = hash2(x, z, this.seed + 701);
        if (top === BLOCK.TURF && treeRoll > 0.985 && hash2(x + 4, z - 7, this.seed + 702) > 0.35) {
          const trunk = 3 + Math.floor(hash2(x, z, this.seed + 703) * 3);
          for (let yy = h + 1; yy <= h + trunk; yy++) this.setLocal(chunk, x, yy, z, BLOCK.LOG);
          for (let dx = -2; dx <= 2; dx++) {
            for (let dz = -2; dz <= 2; dz++) {
              for (let dy = trunk - 2; dy <= trunk + 1; dy++) {
                if (Math.abs(dx) + Math.abs(dz) + Math.max(0, dy - trunk) > 4) continue;
                const yy = h + dy;
                if (this.localBlock(chunk, x + dx, yy, z + dz) === BLOCK.AIR) {
                  this.setLocal(chunk, x + dx, yy, z + dz, BLOCK.LEAVES);
                }
              }
            }
          }
        } else if (top === BLOCK.TURF && treeRoll > 0.972 && treeRoll < 0.978) {
          this.setLocal(chunk, x, h + 1, z, BLOCK.CROP);
        }
      }
    }
  }

  decorateEmber(chunk) {
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;
    for (let x = sx; x < sx + CHUNK_SIZE; x++) {
      for (let z = sz; z < sz + CHUNK_SIZE; z++) {
        const h = this.terrainHeight('ember', x, z);
        if (hash2(x, z, this.seed + 801) > 0.966 && this.localBlock(chunk, x, h + 1, z) === BLOCK.AIR) {
          this.setLocal(chunk, x, h + 1, z, BLOCK.GLOWSHROOM);
        }
        if (hash2(x, z, this.seed + 802) > 0.993) {
          const height = 2 + Math.floor(hash2(x, z, this.seed + 803) * 5);
          for (let y = h + 1; y <= h + height; y++) this.setLocal(chunk, x, y, z, BLOCK.EMBERSTONE);
        }
      }
    }
  }

  decorateAstral(chunk) {
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;
    for (let x = sx; x < sx + CHUNK_SIZE; x++) {
      for (let z = sz; z < sz + CHUNK_SIZE; z++) {
        const top = this.terrainHeight('astral', x, z);
        if (this.localBlock(chunk, x, top, z) !== BLOCK.AIR && hash2(x, z, this.seed + 901) > 0.992) {
          const height = 2 + Math.floor(hash2(x, z, this.seed + 902) * 4);
          for (let y = top + 1; y <= top + height; y++) this.setLocal(chunk, x, y, z, BLOCK.CRYSTAL_ORE);
        }
      }
    }
  }

  getBlock(x, y, z, dimension = this.dimension) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < 0 || y >= WORLD_HEIGHT) return BLOCK.AIR;
    const cx = floorDiv(x, CHUNK_SIZE);
    const cz = floorDiv(z, CHUNK_SIZE);
    const chunk = this.ensureChunk(cx, cz, dimension);
    const lx = ((x % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const lz = ((z % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    return chunk.data[indexOf(lx, y, lz)];
  }

  setBlock(x, y, z, id, dimension = this.dimension, record = true) {
    x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
    if (y < 0 || y >= WORLD_HEIGHT) return;
    const cx = floorDiv(x, CHUNK_SIZE);
    const cz = floorDiv(z, CHUNK_SIZE);
    const chunk = this.ensureChunk(cx, cz, dimension);
    const lx = ((x % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const lz = ((z % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    chunk.data[indexOf(lx, y, lz)] = id;
    if (record) this.dimensions[dimension].edits.set(key3(x, y, z), id);
    this.markDirty(cx, cz, dimension);
    if (lx === 0) this.markDirty(cx - 1, cz, dimension);
    if (lx === CHUNK_SIZE - 1) this.markDirty(cx + 1, cz, dimension);
    if (lz === 0) this.markDirty(cx, cz - 1, dimension);
    if (lz === CHUNK_SIZE - 1) this.markDirty(cx, cz + 1, dimension);
  }

  markDirty(cx, cz, dimension = this.dimension) {
    const state = this.dimensions[dimension];
    const key = chunkKey(cx, cz);
    const chunk = state.chunks.get(key);
    if (chunk) chunk.dirty = true;
    this.enqueueBuild(cx, cz, dimension, true);
  }

  enqueueBuild(cx, cz, dimension = this.dimension, priority = false) {
    const qkey = `${dimension}:${cx},${cz}`;
    if (this.queued.has(qkey)) return;
    this.queued.add(qkey);
    const job = { cx, cz, dimension, qkey };
    if (priority) this.buildQueue.unshift(job);
    else this.buildQueue.push(job);
  }

  updateVisibleChunks(playerX, playerZ, radius = 2) {
    const cx = floorDiv(playerX, CHUNK_SIZE);
    const cz = floorDiv(playerZ, CHUNK_SIZE);
    const centerKey = `${this.dimension}:${cx},${cz}:${radius}`;
    if (centerKey === this.lastCenter) return;
    this.lastCenter = centerKey;

    const wanted = new Set();
    const jobs = [];
    for (let dx = -radius; dx <= radius; dx++) {
      for (let dz = -radius; dz <= radius; dz++) {
        const dist = dx * dx + dz * dz;
        if (dist > (radius + 0.35) * (radius + 0.35)) continue;
        const tx = cx + dx, tz = cz + dz;
        wanted.add(chunkKey(tx, tz));
        jobs.push({ tx, tz, dist });
      }
    }
    jobs.sort((a,b) => a.dist - b.dist);
    for (const { tx, tz } of jobs) {
      const chunk = this.ensureChunk(tx, tz);
      if (!chunk.group || chunk.dirty) this.enqueueBuild(tx, tz);
      if (chunk.group) chunk.group.visible = true;
    }

    for (const [key, chunk] of this.state.chunks) {
      if (chunk.group) chunk.group.visible = wanted.has(key);
    }
  }

  processBuildQueue(maxJobs = 1) {
    let count = 0;
    while (count < maxJobs && this.buildQueue.length) {
      const job = this.buildQueue.shift();
      this.queued.delete(job.qkey);
      const state = this.dimensions[job.dimension];
      const chunk = state.chunks.get(chunkKey(job.cx, job.cz));
      if (!chunk) continue;
      this.rebuildChunk(chunk, job.dimension);
      count++;
    }
    return count;
  }

  rebuildChunk(chunk, dimension = this.dimension) {
    const state = this.dimensions[dimension];
    if (chunk.group) {
      state.group.remove(chunk.group);
      chunk.group.traverse(obj => {
        if (obj.geometry) obj.geometry.dispose();
      });
    }

    const group = new THREE.Group();
    group.name = `chunk:${dimension}:${chunk.cx},${chunk.cz}`;
    group.userData.chunk = chunk;

    const opaque = this.buildGeometry(chunk, dimension, false);
    if (opaque) {
      const mesh = new THREE.Mesh(opaque, this.opaqueMaterial);
      mesh.name = 'opaque-voxels';
      mesh.userData.voxelChunk = true;
      group.add(mesh);
    }

    const transparent = this.buildGeometry(chunk, dimension, true);
    if (transparent) {
      const mesh = new THREE.Mesh(transparent, this.transparentMaterial);
      mesh.name = 'transparent-voxels';
      mesh.userData.voxelChunk = true;
      mesh.renderOrder = 2;
      group.add(mesh);
    }

    chunk.group = group;
    chunk.dirty = false;
    state.group.add(group);
  }

  buildGeometry(chunk, dimension, transparentPass) {
    const positions = [];
    const normals = [];
    const colors = [];
    const indices = [];
    const sx = chunk.cx * CHUNK_SIZE;
    const sz = chunk.cz * CHUNK_SIZE;
    let vertexIndex = 0;

    for (let y = 0; y < WORLD_HEIGHT; y++) {
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        for (let lx = 0; lx < CHUNK_SIZE; lx++) {
          const id = chunk.data[indexOf(lx, y, lz)];
          if (id === BLOCK.AIR) continue;
          const block = BLOCKS[id];
          if (!!block.transparent !== transparentPass) continue;
          const x = sx + lx;
          const z = sz + lz;

          for (let faceIndex = 0; faceIndex < FACE_DEFS.length; faceIndex++) {
            const face = FACE_DEFS[faceIndex];
            const nx = x + face.dir[0];
            const ny = y + face.dir[1];
            const nz = z + face.dir[2];
            const neighborId = this.getBlock(nx, ny, nz, dimension);
            const neighbor = BLOCKS[neighborId];

            let visible = neighborId === BLOCK.AIR;
            if (!visible && neighbor.transparent) {
              visible = neighborId !== id || !block.transparent;
            }
            if (!visible) continue;

            const c = colorForFace(block, faceIndex, x, y, z, this.seed);
            for (const corner of face.corners) {
              positions.push(x + corner[0], y + corner[1], z + corner[2]);
              normals.push(face.dir[0], face.dir[1], face.dir[2]);
              colors.push(c.r, c.g, c.b);
            }
            indices.push(vertexIndex, vertexIndex + 1, vertexIndex + 2, vertexIndex, vertexIndex + 2, vertexIndex + 3);
            vertexIndex += 4;
          }
        }
      }
    }

    if (!positions.length) return null;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geometry.setIndex(indices);
    geometry.computeBoundingSphere();
    return geometry;
  }

  highestSolid(x, z, dimension = this.dimension) {
    // Emberdeep has a solid ceiling; walking surfaces must be found below the cavern air.
    const startY = dimension === 'ember' ? 24 : WORLD_HEIGHT - 2;
    for (let y = startY; y >= 0; y--) {
      const id = this.getBlock(x, y, z, dimension);
      const block = BLOCKS[id];
      if (block && block.collidable !== false && id !== BLOCK.LEAVES) return y;
    }
    return 0;
  }

  stationNearby(position, station, radius = 4) {
    if (station === 'hand') return true;
    const target = station === 'bench' ? BLOCK.WORKBENCH : BLOCK.KILN;
    const px = Math.floor(position.x), py = Math.floor(position.y), pz = Math.floor(position.z);
    for (let x = px - radius; x <= px + radius; x++) {
      for (let y = py - 2; y <= py + 2; y++) {
        for (let z = pz - radius; z <= pz + radius; z++) {
          if (this.getBlock(x, y, z) === target) return true;
        }
      }
    }
    return false;
  }

  exportEdits() {
    const out = {};
    for (const [name, state] of Object.entries(this.dimensions)) {
      out[name] = Array.from(state.edits.entries());
    }
    return out;
  }

  importEdits(data) {
    if (!data) return;
    for (const [name, entries] of Object.entries(data)) {
      if (!this.dimensions[name] || !Array.isArray(entries)) continue;
      this.dimensions[name].edits = new Map(entries);
      for (const chunk of this.dimensions[name].chunks.values()) {
        this.generateChunk(chunk, name);
        chunk.dirty = true;
      }
    }
  }

  clear() {
    for (const state of Object.values(this.dimensions)) {
      for (const chunk of state.chunks.values()) {
        if (chunk.group) {
          state.group.remove(chunk.group);
          chunk.group.traverse(obj => obj.geometry?.dispose());
        }
      }
      state.chunks.clear();
      state.edits.clear();
    }
    this.buildQueue.length = 0;
    this.queued.clear();
  }
}
