
import * as THREE from 'three';
import './styles.css';
import {
  BLOCK, BLOCKS, ITEMS, RECIPES, DIMENSIONS,
  canCraft, craftRecipe, itemName, stationLabel
} from './data.js';
import { seedFromString, hash2 } from './noise.js';
import { VoxelWorld, WORLD_HEIGHT } from './world.js';

const SAVE_KEY = 'blockwild-realms-save-v1';

const app = document.querySelector('#app');
app.innerHTML = `
  <main id="game-shell" aria-label="Blockwild: Realms game">
    <div id="viewport"></div>

    <section id="title-screen" class="screen active" aria-labelledby="game-title">
      <div class="title-card">
        <p class="eyebrow">AN ORIGINAL VOXEL SURVIVAL SANDBOX</p>
        <h1 id="game-title">BLOCKWILD<span>REALMS</span></h1>
        <p class="lede">Shape a living world. Build a path through three dangerous dimensions.</p>

        <label class="field">
          <span>WORLD SEED</span>
          <input id="seed-input" value="wild-horizon" maxlength="40" />
        </label>
        <div class="mode-picker" role="radiogroup" aria-label="Game mode">
          <button class="mode active" data-mode="survival" role="radio" aria-checked="true">
            <strong>Survival</strong><small>Gather, craft, fight, eat</small>
          </button>
          <button class="mode" data-mode="creative" role="radio" aria-checked="false">
            <strong>Creative</strong><small>Fly and build freely</small>
          </button>
        </div>
        <button id="new-world-btn" class="primary-btn">CREATE NEW WORLD</button>
        <button id="continue-btn" class="secondary-btn hidden">CONTINUE SAVED WORLD</button>
        <div class="title-note">
          <span>WASD move</span><span>Mouse look</span><span>Hold left mine</span><span>Right place/use</span><span>E inventory</span>
        </div>
      </div>
      <footer>Original code, procedural art, and original world design. No Minecraft assets are included.</footer>
    </section>

    <section id="loading-screen" class="screen" aria-live="polite">
      <div class="loading-card">
        <div class="voxel-spinner"><i></i><i></i><i></i></div>
        <h2>Forming the realm…</h2>
        <p id="loading-text">Carving terrain</p>
      </div>
    </section>

    <div id="hud" class="hidden">
      <div id="realm-card">
        <span id="realm-name">Verdant Reach</span>
        <small id="realm-subtitle">Forests, rivers, caverns, and long nights</small>
      </div>

      <div id="objective-card">
        <span>PATH FORWARD</span>
        <strong id="objective-text">Gather a Timber Log</strong>
      </div>

      <div id="stats">
        <div class="stat-row"><span>VITALITY</span><div class="bar"><i id="health-fill"></i></div><b id="health-value">20</b></div>
        <div class="stat-row survival-only"><span>ENERGY</span><div class="bar hunger"><i id="hunger-fill"></i></div><b id="hunger-value">20</b></div>
      </div>

      <div id="crosshair" aria-hidden="true"><i></i><i></i></div>
      <div id="target-label"></div>
      <div id="break-meter"><i></i></div>
      <div id="portal-prompt" class="prompt hidden">F — ENTER GATE</div>
      <div id="toast-stack" aria-live="polite"></div>
      <div id="hand-item" aria-hidden="true"></div>

      <div id="hotbar" role="toolbar" aria-label="Quick inventory"></div>
      <div id="day-clock"><span id="clock-icon">☀</span><b id="clock-label">DAY 1 · MORNING</b></div>
    </div>

    <section id="inventory-panel" class="panel hidden" aria-label="Inventory and crafting">
      <header>
        <div><span class="eyebrow">FIELD KIT</span><h2>Inventory & Crafting</h2></div>
        <button class="icon-btn" data-close-panel aria-label="Close inventory">×</button>
      </header>
      <nav class="panel-tabs" aria-label="Inventory sections">
        <button class="active" data-tab="craft">Craft</button>
        <button data-tab="inventory">Inventory</button>
        <button data-tab="guide">Guide</button>
      </nav>
      <div id="craft-tab" class="tab-view">
        <div id="station-status"></div>
        <div id="craft-categories"></div>
        <div id="recipe-list"></div>
      </div>
      <div id="inventory-tab" class="tab-view hidden">
        <div id="inventory-grid"></div>
      </div>
      <div id="guide-tab" class="tab-view hidden">
        <article class="guide">
          <h3>Your route through the realms</h3>
          <ol>
            <li><strong>Build tools.</strong> Fell timber, make an Assembly Bench, mine stone, then construct a Kiln.</li>
            <li><strong>Prepare an Ember Sigil.</strong> Smelt iron, collect Night Essence from Shades, and activate the orange gate.</li>
            <li><strong>Survive Emberdeep.</strong> Mine Aether Crystal and defeat Emberlings for Ember Shards.</li>
            <li><strong>Forge an Astral Sigil.</strong> The violet gate leads to the final floating realm.</li>
          </ol>
          <h3>Controls</h3>
          <dl>
            <div><dt>W A S D</dt><dd>Move</dd></div>
            <div><dt>Mouse</dt><dd>Look</dd></div>
            <div><dt>Space</dt><dd>Jump / fly up</dd></div>
            <div><dt>Shift</dt><dd>Sprint / fly down</dd></div>
            <div><dt>Left mouse</dt><dd>Mine or attack</dd></div>
            <div><dt>Right mouse</dt><dd>Place or eat</dd></div>
            <div><dt>1–9 / wheel</dt><dd>Select hotbar</dd></div>
            <div><dt>E</dt><dd>Inventory and recipes</dd></div>
            <div><dt>F</dt><dd>Use nearby realm gate</dd></div>
            <div><dt>Esc</dt><dd>Pause and release pointer</dd></div>
          </dl>
          <p class="tip">Crafting stations work when you stand within four blocks of them. Food is eaten with right click while selected.</p>
        </article>
      </div>
    </section>

    <section id="pause-panel" class="screen" aria-label="Paused">
      <div class="pause-card">
        <p class="eyebrow">WORLD PAUSED</p>
        <h2>Take a breath.</h2>
        <button id="resume-btn" class="primary-btn">RESUME</button>
        <button id="save-btn" class="secondary-btn">SAVE WORLD</button>
        <button id="export-btn" class="secondary-btn">EXPORT SAVE</button>
        <button id="quit-btn" class="danger-btn">SAVE & EXIT</button>
      </div>
    </section>

    <section id="victory-panel" class="screen" aria-label="Realm reached">
      <div class="victory-card">
        <p class="eyebrow">THE PATH IS OPEN</p>
        <h2>You reached the Starfall Expanse.</h2>
        <p>You completed the main progression route. The world remains open for exploration, building, and survival.</p>
        <button id="continue-playing-btn" class="primary-btn">CONTINUE EXPLORING</button>
      </div>
    </section>

    <div id="damage-flash"></div>
  </main>
`;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

class AudioSynth {
  constructor() {
    this.ctx = null;
  }
  ensure() {
    if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  tone(freq = 220, duration = 0.08, type = 'square', volume = 0.035, slide = 0) {
    this.ensure();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.linearRampToValueAtTime(Math.max(30, freq + slide), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain).connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration);
  }
  mine() { this.tone(115 + Math.random() * 30, 0.045, 'square', 0.018, -25); }
  break() { this.tone(82, 0.11, 'sawtooth', 0.04, -45); }
  place() { this.tone(150, 0.06, 'square', 0.025, 30); }
  craft() { this.tone(420, 0.08, 'triangle', 0.035, 180); }
  hurt() { this.tone(95, 0.18, 'sawtooth', 0.05, -55); }
  portal() {
    this.tone(180, 0.45, 'sine', 0.035, 460);
    setTimeout(() => this.tone(260, 0.4, 'sine', 0.025, 520), 90);
  }
  hit() { this.tone(155, 0.07, 'square', 0.035, -70); }
}

class MobManager {
  constructor(game) {
    this.game = game;
    this.mobs = [];
    this.spawnTimer = 2;
    this.sharedGeometry = new THREE.BoxGeometry(0.78, 0.78, 0.78);
  }

  clear() {
    for (const mob of this.mobs) this.game.scene.remove(mob.group);
    this.mobs.length = 0;
  }

  typePool() {
    if (this.game.dimension === 'verdant') {
      return this.game.isNight() ? ['shade', 'shade', 'grazer'] : ['grazer', 'grazer', 'grazer'];
    }
    if (this.game.dimension === 'ember') return ['emberling', 'emberling', 'pyreboar'];
    return ['voidling', 'voidling', 'stargrazer'];
  }

  spawn() {
    if (this.mobs.length >= 10) return;
    const angle = Math.random() * Math.PI * 2;
    const distance = 10 + Math.random() * 13;
    const x = Math.floor(this.game.player.position.x + Math.cos(angle) * distance);
    const z = Math.floor(this.game.player.position.z + Math.sin(angle) * distance);
    const y = this.game.world.highestSolid(x, z, this.game.dimension) + 1;
    if (y <= 1 || y >= WORLD_HEIGHT - 2) return;
    const floor = BLOCKS[this.game.world.getBlock(x, y - 1, z, this.game.dimension)];
    if (!floor || floor.fluid || floor.damaging) return;

    const pool = this.typePool();
    const type = pool[Math.floor(Math.random() * pool.length)];
    const spec = {
      grazer: { name: 'Moss Grazer', color: 0x8bb66a, head: 0xb1d184, hostile: false, hp: 8, speed: 1.2, drop: 'raw_meat' },
      shade: { name: 'Night Shade', color: 0x302443, head: 0x67517f, hostile: true, hp: 10, speed: 2.0, drop: 'dark_essence' },
      emberling: { name: 'Emberling', color: 0x7a241d, head: 0xff6336, hostile: true, hp: 13, speed: 2.15, drop: 'ember_shard' },
      pyreboar: { name: 'Pyreboar', color: 0x60362d, head: 0xb85a39, hostile: false, hp: 11, speed: 1.15, drop: 'raw_meat' },
      voidling: { name: 'Voidling', color: 0x2a2047, head: 0xa585ff, hostile: true, hp: 16, speed: 2.35, drop: 'star_fragment' },
      stargrazer: { name: 'Star Grazer', color: 0x7770a5, head: 0xd2c8ff, hostile: false, hp: 12, speed: 1.1, drop: 'raw_meat' }
    }[type];

    const group = new THREE.Group();
    const bodyMat = new THREE.MeshLambertMaterial({ color: spec.color, flatShading: true });
    const headMat = new THREE.MeshLambertMaterial({ color: spec.head, flatShading: true });
    const body = new THREE.Mesh(this.sharedGeometry, bodyMat);
    body.scale.set(1.1, 0.8, 1.35);
    body.position.y = 0.55;
    const head = new THREE.Mesh(this.sharedGeometry, headMat);
    head.scale.set(0.78, 0.78, 0.78);
    head.position.set(0, 1.15, -0.48);
    const eyeMat = new THREE.MeshBasicMaterial({ color: spec.hostile ? 0xff5656 : 0x101820 });
    for (const ex of [-0.15, 0.15]) {
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.05), eyeMat);
      eye.position.set(ex, 1.25, -0.82);
      group.add(eye);
    }
    group.add(body, head);
    group.position.set(x + 0.5, y, z + 0.5);

    const mob = {
      ...spec, type, group, hp: spec.hp,
      direction: Math.random() * Math.PI * 2,
      think: Math.random() * 2,
      attackCooldown: 0,
      bob: Math.random() * Math.PI * 2
    };
    group.traverse(obj => { obj.userData.mob = mob; });
    this.game.scene.add(group);
    this.mobs.push(mob);
  }

  update(dt) {
    if (!this.game.running) return;
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnTimer = 3 + Math.random() * 4;
      this.spawn();
    }

    const player = this.game.player.position;
    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const mob = this.mobs[i];
      mob.attackCooldown -= dt;
      mob.think -= dt;
      mob.bob += dt * 4;

      const dx = player.x - mob.group.position.x;
      const dz = player.z - mob.group.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist > 42 || mob.group.position.y < -10) {
        this.game.scene.remove(mob.group);
        this.mobs.splice(i, 1);
        continue;
      }

      let speed = mob.speed;
      if (mob.hostile && dist < 13) {
        mob.direction = Math.atan2(dx, dz);
        if (dist < 1.5 && mob.attackCooldown <= 0 && this.game.mode === 'survival') {
          mob.attackCooldown = 1.1;
          this.game.damagePlayer(mob.type === 'voidling' ? 4 : 3, mob.name);
        }
      } else if (mob.think <= 0) {
        mob.direction += (Math.random() - 0.5) * 2.5;
        mob.think = 1.2 + Math.random() * 3;
        speed *= 0.55;
      } else {
        speed *= 0.55;
      }

      const nx = mob.group.position.x + Math.sin(mob.direction) * speed * dt;
      const nz = mob.group.position.z + Math.cos(mob.direction) * speed * dt;
      const ground = this.game.world.highestSolid(Math.floor(nx), Math.floor(nz), this.game.dimension) + 1;
      if (Math.abs(ground - mob.group.position.y) <= 1.6 && ground > 0) {
        mob.group.position.x = nx;
        mob.group.position.z = nz;
        mob.group.position.y += (ground - mob.group.position.y) * Math.min(1, dt * 10);
      } else {
        mob.direction += Math.PI * (0.5 + Math.random() * 0.5);
      }
      mob.group.rotation.y = mob.direction;
      mob.group.children[0].position.y = 0.55 + Math.sin(mob.bob) * 0.025;
    }
  }

  hit(mob, damage) {
    if (!mob || !this.mobs.includes(mob)) return;
    mob.hp -= damage;
    this.game.audio.hit();
    mob.group.scale.set(1.12, 0.86, 1.12);
    setTimeout(() => mob.group?.scale.set(1,1,1), 90);
    if (mob.hp <= 0) {
      this.game.scene.remove(mob.group);
      this.mobs.splice(this.mobs.indexOf(mob), 1);
      this.game.addItem(mob.drop, 1);
      this.game.toast(`${mob.name} defeated · +1 ${itemName(mob.drop)}`, 'loot');
    }
  }
}

class Game {
  constructor() {
    this.viewport = $('#viewport');
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 180);
    this.camera.rotation.order = 'YXZ';
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = false;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.viewport.appendChild(this.renderer.domElement);

    this.scene.add(new THREE.HemisphereLight(0xbfdcff, 0x293322, 0.72));
    this.ambient = new THREE.AmbientLight(0xffffff, 0.42);
    this.sun = new THREE.DirectionalLight(0xfff1d1, 1.2);
    this.sun.position.set(30, 45, 18);
    this.scene.add(this.ambient, this.sun);

    this.audio = new AudioSynth();
    this.clock = new THREE.Clock();
    this.raycaster = new THREE.Raycaster();
    this.raycaster.far = 6;
    this.center = new THREE.Vector2(0, 0);

    this.world = null;
    this.mobs = new MobManager(this);
    this.mode = 'survival';
    this.dimension = 'verdant';
    this.running = false;
    this.panelOpen = false;
    this.started = false;
    this.paused = false;
    this.victoryShown = false;

    this.player = {
      position: new THREE.Vector3(0, 25, 0),
      velocity: new THREE.Vector3(),
      yaw: 0,
      pitch: 0,
      radius: 0.31,
      height: 1.78,
      grounded: false,
      health: 20,
      hunger: 20,
      hurtTimer: 0,
      attackCooldown: 0
    };

    this.keys = new Set();
    this.mouseDown = false;
    this.inventory = {};
    this.hotbar = Array(9).fill(null);
    this.selected = 0;
    this.timeOfDay = 0.24;
    this.day = 1;
    this.hungerTimer = 0;
    this.regenTimer = 0;
    this.saveTimer = 0;
    this.mineState = { key: null, progress: 0, lastTick: 0 };
    this.portalNearby = null;
    this.activeCategory = 'all';
    this.lastFrame = performance.now();

    this.bindUI();
    this.renderHotbar();
    this.updateContinueButton();
    this.animate();
  }

  bindUI() {
    $$('.mode').forEach(button => button.addEventListener('click', () => {
      $$('.mode').forEach(b => {
        b.classList.toggle('active', b === button);
        b.setAttribute('aria-checked', b === button ? 'true' : 'false');
      });
      this.mode = button.dataset.mode;
    }));

    $('#new-world-btn').addEventListener('click', () => {
      const seedText = $('#seed-input').value.trim() || `realm-${Date.now()}`;
      this.startNew(seedText, this.mode);
    });
    $('#continue-btn').addEventListener('click', () => this.continueSaved());

    this.renderer.domElement.addEventListener('click', () => {
      if (this.started && !this.panelOpen && !this.paused && document.pointerLockElement !== this.renderer.domElement) {
        this.renderer.domElement.requestPointerLock();
      }
    });

    document.addEventListener('pointerlockchange', () => {
      if (!this.started) return;
      if (document.pointerLockElement === this.renderer.domElement) {
        this.paused = false;
        $('#pause-panel').classList.remove('active');
        this.running = true;
      } else if (!this.panelOpen && !$('#victory-panel').classList.contains('active')) {
        this.paused = true;
        this.running = false;
        $('#pause-panel').classList.add('active');
      }
    });

    document.addEventListener('mousemove', event => {
      if (document.pointerLockElement !== this.renderer.domElement || !this.running) return;
      this.player.yaw -= event.movementX * 0.0022;
      this.player.pitch -= event.movementY * 0.0022;
      this.player.pitch = THREE.MathUtils.clamp(this.player.pitch, -Math.PI / 2 + 0.02, Math.PI / 2 - 0.02);
    });

    document.addEventListener('keydown', event => {
      if (['KeyW','KeyA','KeyS','KeyD','Space','ShiftLeft','ShiftRight'].includes(event.code)) event.preventDefault();
      this.keys.add(event.code);

      if (event.code === 'KeyE' && this.started && !event.repeat) {
        event.preventDefault();
        this.toggleInventory();
      }
      if (event.code === 'KeyF' && this.started && !event.repeat && !this.panelOpen) this.usePortal();
      if (event.code.startsWith('Digit') && this.started) {
        const n = Number(event.code.slice(5));
        if (n >= 1 && n <= 9) this.selectSlot(n - 1);
      }
      if (event.code === 'Escape' && this.panelOpen) {
        event.preventDefault();
        this.toggleInventory(false);
      }
    });
    document.addEventListener('keyup', event => this.keys.delete(event.code));

    this.renderer.domElement.addEventListener('mousedown', event => {
      if (!this.running || document.pointerLockElement !== this.renderer.domElement) return;
      this.audio.ensure();
      if (event.button === 0) {
        const hit = this.getRayHit();
        if (hit?.mob && this.player.attackCooldown <= 0) {
          const item = ITEMS[this.hotbar[this.selected]];
          this.player.attackCooldown = 0.42;
          this.mobs.hit(hit.mob, item?.damage ?? 1);
          return;
        }
        this.mouseDown = true;
      }
      if (event.button === 2) this.useSelected();
    });
    document.addEventListener('mouseup', event => {
      if (event.button === 0) {
        this.mouseDown = false;
        this.resetMining();
      }
    });
    this.renderer.domElement.addEventListener('contextmenu', event => event.preventDefault());
    this.renderer.domElement.addEventListener('wheel', event => {
      if (!this.started || this.panelOpen) return;
      const dir = Math.sign(event.deltaY);
      this.selectSlot((this.selected + dir + 9) % 9);
    }, { passive: true });

    $$('[data-close-panel]').forEach(btn => btn.addEventListener('click', () => this.toggleInventory(false)));
    $$('.panel-tabs button').forEach(button => button.addEventListener('click', () => this.switchTab(button.dataset.tab)));
    $('#craft-categories').addEventListener('click', event => {
      const button = event.target.closest('[data-category]');
      if (!button) return;
      this.activeCategory = button.dataset.category;
      this.renderCrafting();
    });
    $('#recipe-list').addEventListener('click', event => {
      const button = event.target.closest('[data-craft]');
      if (!button) return;
      this.craft(button.dataset.craft);
    });
    $('#inventory-grid').addEventListener('click', event => {
      const button = event.target.closest('[data-item]');
      if (!button) return;
      this.assignToHotbar(button.dataset.item);
    });
    $('#hotbar').addEventListener('click', event => {
      const slot = event.target.closest('[data-slot]');
      if (slot) this.selectSlot(Number(slot.dataset.slot));
    });

    $('#resume-btn').addEventListener('click', () => this.renderer.domElement.requestPointerLock());
    $('#save-btn').addEventListener('click', () => { this.save(); this.toast('World saved', 'success'); });
    $('#export-btn').addEventListener('click', () => this.exportSave());
    $('#quit-btn').addEventListener('click', () => this.quitToTitle());
    $('#continue-playing-btn').addEventListener('click', () => {
      $('#victory-panel').classList.remove('active');
      this.renderer.domElement.requestPointerLock();
    });

    addEventListener('resize', () => {
      this.camera.aspect = innerWidth / innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(innerWidth, innerHeight);
    });
    addEventListener('beforeunload', () => { if (this.started) this.save(); });
  }

  updateContinueButton() {
    let save = null;
    try { save = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch {}
    $('#continue-btn').classList.toggle('hidden', !save);
    if (save) $('#continue-btn').textContent = `CONTINUE · ${DIMENSIONS[save.dimension]?.name ?? 'SAVED WORLD'}`;
  }

  async startNew(seedText, mode) {
    localStorage.removeItem(SAVE_KEY);
    await this.initialize({
      seedText,
      seed: seedFromString(seedText),
      mode,
      dimension: 'verdant',
      inventory: {},
      hotbar: Array(9).fill(null),
      selected: 0,
      health: 20,
      hunger: 20,
      timeOfDay: 0.24,
      day: 1,
      edits: null,
      player: null
    });
  }

  async continueSaved() {
    let save;
    try { save = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch {}
    if (!save) {
      this.toast('No valid save found', 'error');
      this.updateContinueButton();
      return;
    }
    await this.initialize(save);
  }

  async initialize(state) {
    $('#title-screen').classList.remove('active');
    $('#loading-screen').classList.add('active');
    $('#loading-text').textContent = 'Carving terrain and placing realm gates';

    this.mobs.clear();
    if (this.world) this.world.clear();
    this.seedText = state.seedText;
    this.seed = state.seed >>> 0;
    this.mode = state.mode || 'survival';
    this.dimension = state.dimension || 'verdant';
    this.inventory = state.inventory || {};
    this.hotbar = Array.isArray(state.hotbar) ? state.hotbar.slice(0, 9) : Array(9).fill(null);
    while (this.hotbar.length < 9) this.hotbar.push(null);
    this.selected = state.selected ?? 0;
    this.player.health = state.health ?? 20;
    this.player.hunger = state.hunger ?? 20;
    this.timeOfDay = state.timeOfDay ?? 0.24;
    this.day = state.day ?? 1;
    this.victoryShown = !!state.victoryShown;

    if (this.mode === 'creative') this.fillCreativeInventory();

    this.world = new VoxelWorld(this.seed, this.scene);
    this.world.importEdits(state.edits);
    this.buildRealmGates();
    this.world.setDimension(this.dimension);
    this.applyDimensionTheme();

    const savedPosition = state.player && state.player.dimension === this.dimension
      ? new THREE.Vector3(state.player.x, state.player.y, state.player.z)
      : null;
    const spawn = savedPosition || this.safeSpawn(this.dimension);
    this.player.position.copy(spawn);
    this.player.velocity.set(0, 0, 0);

    this.world.updateVisibleChunks(spawn.x, spawn.z, 2);
    for (let i = 0; i < 11; i++) {
      this.world.processBuildQueue(1);
      $('#loading-text').textContent = `Meshing nearby terrain · ${i + 1}/11`;
      await new Promise(resolve => setTimeout(resolve, 0));
    }

    this.started = true;
    this.paused = false;
    this.panelOpen = false;
    this.running = true;
    $('#loading-screen').classList.remove('active');
    $('#hud').classList.remove('hidden');
    $('#inventory-panel').classList.add('hidden');
    $('#pause-panel').classList.remove('active');
    document.body.classList.toggle('creative-mode', this.mode === 'creative');
    this.renderAllUI();
    this.toast(`${DIMENSIONS[this.dimension].name} formed from seed “${this.seedText}”`, 'realm');
    this.renderer.domElement.requestPointerLock();
  }

  safeSpawn(dimension, x = 0, z = 0) {
    const y = this.world.highestSolid(x, z, dimension) + 1.02;
    return new THREE.Vector3(x + 0.5, y, z + 0.5);
  }

  buildRealmGates() {
    this.buildGate('verdant', 7, 0, BLOCK.EMBER_PORTAL, BLOCK.BRICK);
    this.buildGate('ember', 0, 7, BLOCK.EMBER_PORTAL, BLOCK.BASALT);
    this.buildGate('ember', 8, 0, BLOCK.STAR_PORTAL, BLOCK.VOIDGLASS);
    this.buildGate('astral', 0, 7, BLOCK.STAR_PORTAL, BLOCK.STARSTONE);
  }

  buildGate(dimension, centerX, centerZ, portalId, frameId) {
    const baseY = this.world.highestSolid(centerX, centerZ, dimension);
    for (let x = centerX - 3; x <= centerX + 3; x++) {
      for (let z = centerZ - 2; z <= centerZ + 2; z++) {
        for (let y = baseY + 1; y <= baseY + 6; y++) {
          this.world.setBlock(x, y, z, BLOCK.AIR, dimension, false);
        }
      }
    }
    for (let dx = -2; dx <= 2; dx++) {
      this.world.setBlock(centerX + dx, baseY + 1, centerZ, frameId, dimension, false);
      this.world.setBlock(centerX + dx, baseY + 5, centerZ, frameId, dimension, false);
    }
    for (let dy = 1; dy <= 5; dy++) {
      this.world.setBlock(centerX - 2, baseY + dy, centerZ, frameId, dimension, false);
      this.world.setBlock(centerX + 2, baseY + dy, centerZ, frameId, dimension, false);
    }
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = 2; dy <= 4; dy++) {
        this.world.setBlock(centerX + dx, baseY + dy, centerZ, portalId, dimension, false);
      }
    }
  }

  fillCreativeInventory() {
    for (const [id, item] of Object.entries(ITEMS)) {
      if (item.blockId !== undefined || item.tool || item.food || item.key) this.inventory[id] = 999;
    }
    const defaults = [
      'block:turf','block:stone','block:log','block:planks','block:glass',
      'block:torch','block:emberstone','block:starstone','crystal_pickaxe'
    ];
    defaults.forEach((id, i) => this.hotbar[i] = id);
  }

  renderAllUI() {
    this.renderHotbar();
    this.renderInventory();
    this.renderCrafting();
    this.updateHUD();
    this.updateRealmCard();
  }

  applyDimensionTheme() {
    const spec = DIMENSIONS[this.dimension];
    this.scene.background = new THREE.Color(spec.sky);
    this.scene.fog = new THREE.Fog(spec.fog, 18, 70);
    this.ambient.color.setHex(spec.ambient);
    this.sun.color.setHex(spec.sunlight);
    this.renderer.domElement.dataset.realm = this.dimension;
    this.updateRealmCard();
  }

  updateRealmCard() {
    const spec = DIMENSIONS[this.dimension];
    $('#realm-name').textContent = spec.name;
    $('#realm-subtitle').textContent = spec.subtitle;
  }

  toggleInventory(force) {
    if (!this.started) return;
    const open = force ?? !this.panelOpen;
    this.panelOpen = open;
    $('#inventory-panel').classList.toggle('hidden', !open);
    if (open) {
      document.exitPointerLock();
      this.running = false;
      this.paused = false;
      $('#pause-panel').classList.remove('active');
      this.renderInventory();
      this.renderCrafting();
    } else {
      this.renderer.domElement.requestPointerLock();
    }
  }

  switchTab(tab) {
    $$('.panel-tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    $$('.tab-view').forEach(view => view.classList.add('hidden'));
    $(`#${tab}-tab`).classList.remove('hidden');
    if (tab === 'inventory') this.renderInventory();
    if (tab === 'craft') this.renderCrafting();
  }

  renderCrafting() {
    if (!this.world) return;
    const stations = {
      hand: true,
      bench: this.world.stationNearby(this.player.position, 'bench'),
      kiln: this.world.stationNearby(this.player.position, 'kiln')
    };
    $('#station-status').innerHTML = `
      <span class="station ${stations.bench ? 'ready' : ''}">🛠 ${stations.bench ? 'Bench in range' : 'No bench nearby'}</span>
      <span class="station ${stations.kiln ? 'ready' : ''}">♨ ${stations.kiln ? 'Kiln in range' : 'No kiln nearby'}</span>
    `;
    const categories = ['all', ...new Set(RECIPES.map(r => r.category))];
    $('#craft-categories').innerHTML = categories.map(category =>
      `<button class="${this.activeCategory === category ? 'active' : ''}" data-category="${category}">${category}</button>`
    ).join('');

    const recipes = RECIPES.filter(r => this.activeCategory === 'all' || r.category === this.activeCategory);
    $('#recipe-list').innerHTML = recipes.map(recipe => {
      const [outId, count] = recipe.out;
      const possible = this.mode === 'creative' || canCraft(recipe, this.inventory, station => stations[station]);
      const ingredientHtml = Object.entries(recipe.in).map(([id, needed]) => {
        const owned = this.inventory[id] ?? 0;
        return `<span class="${owned >= needed ? 'owned' : 'missing'}">${ITEMS[id]?.icon ?? '◆'} ${itemName(id)} ${owned}/${needed}</span>`;
      }).join('');
      return `
        <article class="recipe-card ${possible ? '' : 'locked'}">
          <div class="recipe-icon" style="--item:${ITEMS[outId]?.color ?? '#888'}">${ITEMS[outId]?.icon ?? '◆'}</div>
          <div class="recipe-copy">
            <h3>${recipe.name}<small>×${count}</small></h3>
            <p>${stationLabel(recipe.station)}</p>
            <div class="ingredients">${ingredientHtml}</div>
          </div>
          <button data-craft="${recipe.id}" ${possible ? '' : 'disabled'}>CRAFT</button>
        </article>
      `;
    }).join('');
  }

  renderInventory() {
    const entries = Object.entries(this.inventory)
      .filter(([, count]) => count > 0)
      .sort(([a], [b]) => itemName(a).localeCompare(itemName(b)));
    $('#inventory-grid').innerHTML = entries.length ? entries.map(([id, count]) => `
      <button class="inventory-item" data-item="${id}" title="Add to selected hotbar slot">
        <i style="--item:${ITEMS[id]?.color ?? '#777'}">${ITEMS[id]?.icon ?? '◆'}</i>
        <span>${itemName(id)}</span>
        <b>${this.mode === 'creative' ? '∞' : count}</b>
      </button>
    `).join('') : `<div class="empty-state"><strong>Your pack is empty.</strong><span>Mine blocks and defeat creatures to collect materials.</span></div>`;
  }

  renderHotbar() {
    $('#hotbar').innerHTML = this.hotbar.map((id, index) => {
      const count = id ? (this.inventory[id] ?? 0) : 0;
      const item = ITEMS[id];
      const empty = !id || (count <= 0 && this.mode !== 'creative');
      return `
        <button class="hot-slot ${index === this.selected ? 'selected' : ''} ${empty ? 'empty' : ''}" data-slot="${index}" aria-label="Slot ${index + 1}${item ? ` ${item.name}` : ''}">
          <kbd>${index + 1}</kbd>
          ${item ? `<i style="--item:${item.color ?? '#777'}">${item.icon ?? '◆'}</i><b>${this.mode === 'creative' ? '∞' : count}</b>` : ''}
        </button>
      `;
    }).join('');
    const selectedId = this.hotbar[this.selected];
    const selectedItem = ITEMS[selectedId];
    $('#hand-item').innerHTML = selectedItem ? `<i style="--item:${selectedItem.color ?? '#888'}">${selectedItem.icon ?? '◆'}</i>` : '';
  }

  selectSlot(index) {
    this.selected = THREE.MathUtils.clamp(index, 0, 8);
    this.renderHotbar();
  }

  assignToHotbar(id) {
    this.hotbar[this.selected] = id;
    this.renderHotbar();
    this.toast(`${itemName(id)} assigned to slot ${this.selected + 1}`, 'info');
  }

  addItem(id, count = 1) {
    if (!id) return;
    this.inventory[id] = (this.inventory[id] ?? 0) + count;
    if (!this.hotbar.includes(id)) {
      const empty = this.hotbar.findIndex(slot => !slot || (this.inventory[slot] ?? 0) <= 0);
      if (empty >= 0) this.hotbar[empty] = id;
    }
    this.renderHotbar();
  }

  consumeItem(id, count = 1) {
    if (this.mode === 'creative') return true;
    if ((this.inventory[id] ?? 0) < count) return false;
    this.inventory[id] -= count;
    this.renderHotbar();
    return true;
  }

  craft(recipeId) {
    const recipe = RECIPES.find(r => r.id === recipeId);
    if (!recipe) return;
    const stationAvailable = station => this.world.stationNearby(this.player.position, station);
    if (this.mode !== 'creative' && !canCraft(recipe, this.inventory, stationAvailable)) {
      this.toast('Missing materials or required station', 'error');
      return;
    }
    if (this.mode === 'creative') {
      const [outId, outCount] = recipe.out;
      this.addItem(outId, outCount);
    } else {
      craftRecipe(recipe, this.inventory);
      const [outId] = recipe.out;
      if (!this.hotbar.includes(outId)) {
        const empty = this.hotbar.findIndex(slot => !slot || (this.inventory[slot] ?? 0) <= 0);
        if (empty >= 0) this.hotbar[empty] = outId;
      }
    }
    this.audio.craft();
    this.toast(`Crafted ${recipe.name}`, 'success');
    this.renderInventory();
    this.renderCrafting();
    this.renderHotbar();
    this.save();
  }

  getRayHit() {
    this.raycaster.setFromCamera(this.center, this.camera);
    const hits = this.raycaster.intersectObjects(this.scene.children, true);
    for (const hit of hits) {
      if (hit.distance > this.raycaster.far) continue;
      const mob = hit.object.userData.mob;
      if (mob) return { ...hit, mob };
      if (hit.object.userData.voxelChunk && hit.face) {
        const inward = hit.point.clone().addScaledVector(hit.face.normal, -0.01);
        const outward = hit.point.clone().addScaledVector(hit.face.normal, 0.01);
        return {
          ...hit,
          block: {
            x: Math.floor(inward.x),
            y: Math.floor(inward.y),
            z: Math.floor(inward.z),
            id: this.world.getBlock(inward.x, inward.y, inward.z)
          },
          place: {
            x: Math.floor(outward.x),
            y: Math.floor(outward.y),
            z: Math.floor(outward.z)
          }
        };
      }
    }
    return null;
  }

  updateTarget() {
    if (!this.running) {
      $('#target-label').textContent = '';
      return;
    }
    const hit = this.getRayHit();
    if (hit?.mob) {
      $('#target-label').textContent = `${hit.mob.name} · ${Math.max(0, hit.mob.hp)} vitality`;
    } else if (hit?.block) {
      $('#target-label').textContent = BLOCKS[hit.block.id]?.name ?? '';
    } else {
      $('#target-label').textContent = '';
    }
  }

  updateMining(dt) {
    if (!this.mouseDown || !this.running) {
      this.resetMining();
      return;
    }
    const hit = this.getRayHit();
    if (!hit?.block) {
      this.resetMining();
      return;
    }
    const { x, y, z, id } = hit.block;
    const block = BLOCKS[id];
    if (!block || block.hardness >= 9999 || id === BLOCK.AIR || id === BLOCK.WATER || id === BLOCK.LAVA) {
      this.resetMining();
      return;
    }
    const key = `${x},${y},${z}`;
    if (this.mineState.key !== key) {
      this.mineState.key = key;
      this.mineState.progress = 0;
      this.mineState.lastTick = 0;
    }

    const selected = ITEMS[this.hotbar[this.selected]];
    let speed = 0.55;
    if (selected?.tool === block.preferred) speed = selected.speed;
    else if (!block.preferred) speed = selected?.speed ?? 1.0;
    else if (selected?.tool) speed = 0.38;
    if (this.mode === 'creative') speed = 100;

    this.mineState.progress += dt * speed / Math.max(0.12, block.hardness);
    this.mineState.lastTick += dt;
    if (this.mineState.lastTick > 0.16) {
      this.mineState.lastTick = 0;
      this.audio.mine();
    }
    $('#break-meter').classList.add('active');
    $('#break-meter i').style.transform = `scaleX(${Math.min(1, this.mineState.progress)})`;

    if (this.mineState.progress >= 1) {
      const tier = selected?.tier ?? 0;
      const validDrop = !block.minTier || tier >= block.minTier || this.mode === 'creative';
      this.world.setBlock(x, y, z, BLOCK.AIR);
      if (validDrop && block.drop && this.mode !== 'creative') {
        const amount = block.drop === 'fiber' && Math.random() < 0.45 ? 1 : 1;
        this.addItem(block.drop, amount);
      }
      this.audio.break();
      this.toast(validDrop && block.drop ? `Collected ${itemName(block.drop)}` : `${block.name} broken`, 'loot');
      this.resetMining();
      this.saveTimer = Math.max(this.saveTimer, 20);
    }
  }

  resetMining() {
    this.mineState.key = null;
    this.mineState.progress = 0;
    $('#break-meter').classList.remove('active');
    $('#break-meter i').style.transform = 'scaleX(0)';
  }

  useSelected() {
    const id = this.hotbar[this.selected];
    const item = ITEMS[id];
    if (!item || ((this.inventory[id] ?? 0) <= 0 && this.mode !== 'creative')) return;

    if (item.food) {
      if (this.player.hunger >= 20 && this.mode === 'survival') {
        this.toast('You are already full', 'info');
        return;
      }
      if (this.consumeItem(id, 1)) {
        this.player.hunger = Math.min(20, this.player.hunger + item.food);
        this.audio.craft();
        this.toast(`Ate ${item.name} · +${item.food} energy`, 'success');
      }
      return;
    }

    if (item.blockId === undefined) return;
    const hit = this.getRayHit();
    if (!hit?.place || hit.mob) return;
    const { x, y, z } = hit.place;
    const existing = this.world.getBlock(x, y, z);
    if (existing !== BLOCK.AIR && existing !== BLOCK.WATER && existing !== BLOCK.LAVA) return;

    const block = BLOCKS[item.blockId];
    if (block.collidable !== false && this.blockIntersectsPlayer(x, y, z)) {
      this.toast('Cannot place a solid block inside yourself', 'error');
      return;
    }
    if (!this.consumeItem(id, 1)) return;
    this.world.setBlock(x, y, z, item.blockId);
    this.audio.place();
    this.saveTimer = Math.max(this.saveTimer, 20);
  }

  blockIntersectsPlayer(x, y, z) {
    const p = this.player.position;
    const r = this.player.radius;
    return (
      x + 1 > p.x - r && x < p.x + r &&
      y + 1 > p.y && y < p.y + this.player.height &&
      z + 1 > p.z - r && z < p.z + r
    );
  }

  stationAt(position) {
    const id = this.world.getBlock(position.x, position.y, position.z);
    return BLOCKS[id]?.station;
  }

  findPortal() {
    const px = Math.floor(this.player.position.x);
    const py = Math.floor(this.player.position.y);
    const pz = Math.floor(this.player.position.z);
    let closest = null;
    for (let x = px - 3; x <= px + 3; x++) {
      for (let y = py - 3; y <= py + 4; y++) {
        for (let z = pz - 3; z <= pz + 3; z++) {
          const id = this.world.getBlock(x, y, z);
          if (id !== BLOCK.EMBER_PORTAL && id !== BLOCK.STAR_PORTAL) continue;
          const distance = Math.hypot(x + 0.5 - this.player.position.x, y + 0.5 - (this.player.position.y + 1), z + 0.5 - this.player.position.z);
          if (!closest || distance < closest.distance) closest = { id, x, y, z, distance };
        }
      }
    }
    return closest;
  }

  usePortal() {
    const portal = this.findPortal();
    if (!portal || portal.distance > 4.2) return;

    let target;
    let key;
    if (this.dimension === 'verdant' && portal.id === BLOCK.EMBER_PORTAL) {
      target = 'ember'; key = 'ember_key';
    } else if (this.dimension === 'ember' && portal.id === BLOCK.EMBER_PORTAL) {
      target = 'verdant';
    } else if (this.dimension === 'ember' && portal.id === BLOCK.STAR_PORTAL) {
      target = 'astral'; key = 'star_key';
    } else if (this.dimension === 'astral' && portal.id === BLOCK.STAR_PORTAL) {
      target = 'ember';
    }
    if (!target) return;
    if (key && this.mode !== 'creative' && (this.inventory[key] ?? 0) <= 0) {
      this.toast(`The gate needs an ${itemName(key)}`, 'error');
      return;
    }
    this.travel(target);
  }

  async travel(target) {
    this.running = false;
    document.exitPointerLock();
    $('#loading-screen').classList.add('active');
    $('#loading-text').textContent = `Crossing into ${DIMENSIONS[target].name}`;
    this.audio.portal();
    await new Promise(resolve => setTimeout(resolve, 350));

    this.mobs.clear();
    this.dimension = target;
    this.world.setDimension(target);
    this.applyDimensionTheme();
    const spawnMap = {
      verdant: [4, -3],
      ember: [3, 4],
      astral: [3, 4]
    };
    const [sx, sz] = spawnMap[target];
    this.player.position.copy(this.safeSpawn(target, sx, sz));
    this.player.velocity.set(0, 0, 0);
    this.world.updateVisibleChunks(this.player.position.x, this.player.position.z, 2);
    for (let i = 0; i < 8; i++) {
      this.world.processBuildQueue(1);
      await new Promise(resolve => setTimeout(resolve, 0));
    }
    $('#loading-screen').classList.remove('active');
    $('#pause-panel').classList.remove('active');
    this.paused = false;
    this.running = true;
    this.updateRealmCard();
    this.toast(`Entered ${DIMENSIONS[target].name}`, 'realm');
    this.save();
    if (target === 'astral' && !this.victoryShown) {
      this.victoryShown = true;
      this.running = false;
      $('#victory-panel').classList.add('active');
    } else {
      this.renderer.domElement.requestPointerLock();
    }
  }

  updatePortalPrompt() {
    if (!this.world || !this.started) return;
    this.portalNearby = this.findPortal();
    const show = this.portalNearby && this.portalNearby.distance <= 4.2;
    $('#portal-prompt').classList.toggle('hidden', !show);
    if (show) {
      let label = 'F — ENTER GATE';
      if (this.dimension === 'verdant') label = (this.inventory.ember_key ?? 0) > 0 || this.mode === 'creative'
        ? 'F — ENTER EMBERDEEP'
        : 'F — NEED EMBER SIGIL';
      if (this.dimension === 'ember' && this.portalNearby.id === BLOCK.STAR_PORTAL) label =
        (this.inventory.star_key ?? 0) > 0 || this.mode === 'creative' ? 'F — ENTER STARFALL' : 'F — NEED ASTRAL SIGIL';
      if ((this.dimension === 'ember' && this.portalNearby.id === BLOCK.EMBER_PORTAL) || this.dimension === 'astral') label = 'F — RETURN THROUGH GATE';
      $('#portal-prompt').textContent = label;
    }
  }

  isNight() {
    return this.dimension === 'verdant' && (this.timeOfDay < 0.17 || this.timeOfDay > 0.77);
  }

  updateSky(dt) {
    if (this.dimension === 'verdant') {
      this.timeOfDay += dt / 420;
      if (this.timeOfDay >= 1) {
        this.timeOfDay -= 1;
        this.day += 1;
      }
      const angle = this.timeOfDay * Math.PI * 2 - Math.PI / 2;
      const sunHeight = Math.sin(angle);
      const daylight = THREE.MathUtils.clamp((sunHeight + 0.22) / 1.05, 0.04, 1);
      const dayColor = new THREE.Color(0x78b9e8);
      const nightColor = new THREE.Color(0x07101f);
      this.scene.background.copy(nightColor).lerp(dayColor, daylight);
      this.scene.fog.color.copy(this.scene.background);
      this.sun.intensity = 0.12 + daylight * 1.18;
      this.ambient.intensity = 0.18 + daylight * 0.42;
      this.sun.position.set(Math.cos(angle) * 45, sunHeight * 48, Math.sin(angle) * 25);
    } else if (this.dimension === 'ember') {
      this.sun.intensity = 0.65;
      this.ambient.intensity = 0.5;
    } else {
      this.sun.intensity = 0.82;
      this.ambient.intensity = 0.48;
    }
  }

  updateClock() {
    let phase = 'DAY';
    let icon = '☀';
    if (this.dimension === 'verdant') {
      if (this.timeOfDay < 0.17 || this.timeOfDay > 0.77) { phase = 'NIGHT'; icon = '☾'; }
      else if (this.timeOfDay < 0.30) { phase = 'MORNING'; icon = '◒'; }
      else if (this.timeOfDay > 0.64) { phase = 'EVENING'; icon = '◓'; }
      $('#clock-label').textContent = `DAY ${this.day} · ${phase}`;
    } else {
      $('#clock-label').textContent = this.dimension === 'ember' ? 'TIMELESS CAVERN' : 'ENDLESS TWILIGHT';
      icon = this.dimension === 'ember' ? '◉' : '✦';
    }
    $('#clock-icon').textContent = icon;
  }

  updatePlayer(dt) {
    const p = this.player;
    p.attackCooldown = Math.max(0, p.attackCooldown - dt);
    p.hurtTimer = Math.max(0, p.hurtTimer - dt);

    const forward = Number(this.keys.has('KeyW')) - Number(this.keys.has('KeyS'));
    const strafe = Number(this.keys.has('KeyD')) - Number(this.keys.has('KeyA'));
    const sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
    const inputLength = Math.hypot(forward, strafe) || 1;
    const sin = Math.sin(p.yaw), cos = Math.cos(p.yaw);
    const moveX = (strafe * cos - forward * sin) / inputLength;
    const moveZ = (-forward * cos - strafe * sin) / inputLength;

    if (this.mode === 'creative') {
      const speed = sprint ? 15 : 9;
      const up = Number(this.keys.has('Space')) - Number(sprint);
      p.velocity.x = moveX * speed;
      p.velocity.z = moveZ * speed;
      p.velocity.y = up * speed;
      p.position.addScaledVector(p.velocity, dt);
    } else {
      const speed = sprint && p.hunger > 3 ? 6.7 : 4.5;
      const accel = p.grounded ? 16 : 6;
      p.velocity.x += (moveX * speed - p.velocity.x) * Math.min(1, accel * dt);
      p.velocity.z += (moveZ * speed - p.velocity.z) * Math.min(1, accel * dt);
      p.velocity.y -= DIMENSIONS[this.dimension].gravity * dt;

      if (this.keys.has('Space') && p.grounded) {
        p.velocity.y = this.dimension === 'astral' ? 7.3 : 8.2;
        p.grounded = false;
      }

      this.moveWithCollisions('x', p.velocity.x * dt);
      this.moveWithCollisions('z', p.velocity.z * dt);
      p.grounded = false;
      this.moveWithCollisions('y', p.velocity.y * dt);

      this.updateSurvival(dt, sprint && (forward || strafe));
    }

    if (p.position.y < -12) {
      if (this.mode === 'survival') this.damagePlayer(100, 'the void');
      else p.position.copy(this.safeSpawn(this.dimension));
    }

    this.camera.position.set(p.position.x, p.position.y + 1.62, p.position.z);
    this.camera.rotation.y = p.yaw;
    this.camera.rotation.x = p.pitch;
  }

  moveWithCollisions(axis, amount) {
    if (!amount) return;
    const p = this.player;
    const original = p.position[axis];
    p.position[axis] += amount;
    if (this.playerCollides(p.position)) {
      p.position[axis] = original;
      if (axis === 'y') {
        if (amount < 0) p.grounded = true;
        p.velocity.y = 0;
      } else {
        p.velocity[axis] = 0;
      }
    }
  }

  playerCollides(position) {
    const r = this.player.radius;
    const minX = Math.floor(position.x - r);
    const maxX = Math.floor(position.x + r);
    const minY = Math.floor(position.y + 0.02);
    const maxY = Math.floor(position.y + this.player.height - 0.02);
    const minZ = Math.floor(position.z - r);
    const maxZ = Math.floor(position.z + r);
    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          const block = BLOCKS[this.world.getBlock(x, y, z)];
          if (block && block.collidable !== false) return true;
        }
      }
    }
    return false;
  }

  updateSurvival(dt, sprinting) {
    this.hungerTimer += dt * (sprinting ? 2.2 : 1);
    if (this.hungerTimer > 18) {
      this.hungerTimer = 0;
      this.player.hunger = Math.max(0, this.player.hunger - 1);
    }
    if (this.player.hunger >= 17 && this.player.health < 20) {
      this.regenTimer += dt;
      if (this.regenTimer > 4) {
        this.regenTimer = 0;
        this.player.health = Math.min(20, this.player.health + 1);
        this.player.hunger = Math.max(0, this.player.hunger - 0.5);
      }
    } else if (this.player.hunger <= 0) {
      this.regenTimer += dt;
      if (this.regenTimer > 5) {
        this.regenTimer = 0;
        this.damagePlayer(1, 'starvation');
      }
    } else {
      this.regenTimer = 0;
    }

    const feet = this.world.getBlock(this.player.position.x, this.player.position.y, this.player.position.z);
    const waist = this.world.getBlock(this.player.position.x, this.player.position.y + 0.8, this.player.position.z);
    if ((BLOCKS[feet]?.damaging || BLOCKS[waist]?.damaging) && this.player.hurtTimer <= 0) {
      this.damagePlayer(3, 'magma');
    }
  }

  damagePlayer(amount, source = 'danger') {
    if (this.mode !== 'survival' || this.player.hurtTimer > 0) return;
    this.player.health -= amount;
    this.player.hurtTimer = 0.7;
    this.audio.hurt();
    $('#damage-flash').classList.remove('flash');
    void $('#damage-flash').offsetWidth;
    $('#damage-flash').classList.add('flash');
    if (this.player.health <= 0) {
      this.respawn(source);
    }
  }

  respawn(source) {
    this.toast(`You fell to ${source}. Returning to the realm anchor.`, 'error');
    this.player.health = 20;
    this.player.hunger = 14;
    this.player.velocity.set(0,0,0);
    this.player.position.copy(this.safeSpawn(this.dimension));
  }

  updateHUD() {
    const health = this.mode === 'creative' ? 20 : this.player.health;
    const hunger = this.mode === 'creative' ? 20 : this.player.hunger;
    $('#health-fill').style.transform = `scaleX(${THREE.MathUtils.clamp(health / 20, 0, 1)})`;
    $('#hunger-fill').style.transform = `scaleX(${THREE.MathUtils.clamp(hunger / 20, 0, 1)})`;
    $('#health-value').textContent = this.mode === 'creative' ? '∞' : Math.ceil(health);
    $('#hunger-value').textContent = this.mode === 'creative' ? '∞' : Math.ceil(hunger);
    $('#objective-text').textContent = this.currentObjective();
  }

  currentObjective() {
    if (this.mode === 'creative') return 'Build freely · Realm gates are unlocked';
    if ((this.inventory['block:log'] ?? 0) < 1 && (this.inventory['block:planks'] ?? 0) < 1) return 'Gather a Timber Log';
    if ((this.inventory['block:workbench'] ?? 0) < 1 && !this.world.stationNearby(this.player.position, 'bench')) return 'Craft and place an Assembly Bench';
    if (!(this.inventory.stone_pickaxe || this.inventory.iron_pickaxe || this.inventory.crystal_pickaxe)) return 'Craft a Stone Pick';
    if ((this.inventory['block:kiln'] ?? 0) < 1 && !this.world.stationNearby(this.player.position, 'kiln')) return 'Craft and place a Stone Kiln';
    if ((this.inventory.ember_key ?? 0) < 1) return 'Forge an Ember Sigil';
    if (this.dimension === 'verdant') return 'Enter the orange gate';
    if ((this.inventory.star_key ?? 0) < 1) return 'Mine crystal and forge an Astral Sigil';
    if (this.dimension === 'ember') return 'Enter the violet gate';
    return 'Explore, build, and master Starfall';
  }

  toast(message, type = 'info') {
    const node = document.createElement('div');
    node.className = `toast ${type}`;
    node.textContent = message;
    $('#toast-stack').appendChild(node);
    requestAnimationFrame(() => node.classList.add('show'));
    setTimeout(() => {
      node.classList.remove('show');
      setTimeout(() => node.remove(), 300);
    }, 2600);
  }

  save() {
    if (!this.started || !this.world) return;
    const save = {
      version: 1,
      seedText: this.seedText,
      seed: this.seed,
      mode: this.mode,
      dimension: this.dimension,
      inventory: this.inventory,
      hotbar: this.hotbar,
      selected: this.selected,
      health: this.player.health,
      hunger: this.player.hunger,
      timeOfDay: this.timeOfDay,
      day: this.day,
      victoryShown: this.victoryShown,
      player: {
        x: this.player.position.x,
        y: this.player.position.y,
        z: this.player.position.z,
        dimension: this.dimension
      },
      edits: this.world.exportEdits()
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(save));
      this.updateContinueButton();
    } catch (error) {
      console.error(error);
      this.toast('Save storage is full. Export your save from the pause menu.', 'error');
    }
  }

  exportSave() {
    this.save();
    const data = localStorage.getItem(SAVE_KEY);
    if (!data) return;
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `blockwild-${this.seedText.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    this.toast('Save exported', 'success');
  }

  quitToTitle() {
    this.save();
    document.exitPointerLock();
    this.running = false;
    this.started = false;
    this.paused = false;
    this.panelOpen = false;
    this.mobs.clear();
    $('#hud').classList.add('hidden');
    $('#pause-panel').classList.remove('active');
    $('#inventory-panel').classList.add('hidden');
    $('#title-screen').classList.add('active');
    this.updateContinueButton();
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    const dt = Math.min(0.05, this.clock.getDelta());

    if (this.started && this.running && this.world) {
      this.updateSky(dt);
      this.updatePlayer(dt);
      this.world.updateVisibleChunks(this.player.position.x, this.player.position.z, 2);
      this.world.processBuildQueue(1);
      this.mobs.update(dt);
      this.updateMining(dt);

      this.saveTimer += dt;
      if (this.saveTimer > 30) {
        this.saveTimer = 0;
        this.save();
      }
    }

    if (this.started && this.world) {
      this.updateTarget();
      this.updatePortalPrompt();
      this.updateClock();
      this.updateHUD();
    }

    this.renderer.render(this.scene, this.camera);
  }
}

new Game();
