
export const BLOCK = Object.freeze({
  AIR: 0,
  TURF: 1,
  LOAM: 2,
  STONE: 3,
  LOG: 4,
  LEAVES: 5,
  SAND: 6,
  WATER: 7,
  COAL_ORE: 8,
  COPPER_ORE: 9,
  IRON_ORE: 10,
  CRYSTAL_ORE: 11,
  PLANKS: 12,
  BRICK: 13,
  GLASS: 14,
  EMBERSTONE: 15,
  ASH: 16,
  GLOWSHROOM: 17,
  STARSTONE: 18,
  VOIDGLASS: 19,
  WORKBENCH: 20,
  KILN: 21,
  EMBER_PORTAL: 22,
  STAR_PORTAL: 23,
  TORCH: 24,
  CROP: 25,
  SNOW: 26,
  BASALT: 27,
  LAVA: 28,
  CLOUDSTONE: 29
});

export const BLOCKS = {
  [BLOCK.AIR]: { key: 'air', name: 'Air', color: 0x000000, transparent: true, collidable: false, hardness: 0, drop: null },
  [BLOCK.TURF]: { key: 'turf', name: 'Turf', color: 0x5f9d45, sideColor: 0x7a5a38, hardness: 0.75, drop: 'block:loam', preferred: 'shovel' },
  [BLOCK.LOAM]: { key: 'loam', name: 'Loam', color: 0x795638, hardness: 0.65, drop: 'block:loam', preferred: 'shovel' },
  [BLOCK.STONE]: { key: 'stone', name: 'Stone', color: 0x74797c, hardness: 2.4, drop: 'block:stone', preferred: 'pickaxe', minTier: 1 },
  [BLOCK.LOG]: { key: 'log', name: 'Timber Log', color: 0x7b4d2a, topColor: 0xb58452, hardness: 1.5, drop: 'block:log', preferred: 'axe' },
  [BLOCK.LEAVES]: { key: 'leaves', name: 'Leaf Cluster', color: 0x3f7d3c, transparent: true, alpha: 0.82, hardness: 0.2, drop: 'fiber', collidable: true },
  [BLOCK.SAND]: { key: 'sand', name: 'Sun Sand', color: 0xd8c17a, hardness: 0.6, drop: 'block:sand', preferred: 'shovel' },
  [BLOCK.WATER]: { key: 'water', name: 'Water', color: 0x3579ba, transparent: true, alpha: 0.55, collidable: false, hardness: 9999, drop: null, fluid: true },
  [BLOCK.COAL_ORE]: { key: 'coal_ore', name: 'Cinder Ore', color: 0x4b4c4f, fleck: 0x17191b, hardness: 2.8, drop: 'coal', preferred: 'pickaxe', minTier: 1 },
  [BLOCK.COPPER_ORE]: { key: 'copper_ore', name: 'Copper Ore', color: 0x7e746c, fleck: 0xc77c4e, hardness: 3.0, drop: 'copper_ore', preferred: 'pickaxe', minTier: 1 },
  [BLOCK.IRON_ORE]: { key: 'iron_ore', name: 'Iron Ore', color: 0x77726d, fleck: 0xd0b594, hardness: 3.3, drop: 'iron_ore', preferred: 'pickaxe', minTier: 2 },
  [BLOCK.CRYSTAL_ORE]: { key: 'crystal_ore', name: 'Aether Crystal Ore', color: 0x424a66, fleck: 0x6ff1ff, emissive: true, hardness: 4.4, drop: 'crystal', preferred: 'pickaxe', minTier: 3 },
  [BLOCK.PLANKS]: { key: 'planks', name: 'Timber Boards', color: 0xb67e43, hardness: 1.4, drop: 'block:planks', preferred: 'axe' },
  [BLOCK.BRICK]: { key: 'brick', name: 'Stone Brick', color: 0x8a8d8f, hardness: 2.7, drop: 'block:brick', preferred: 'pickaxe', minTier: 1 },
  [BLOCK.GLASS]: { key: 'glass', name: 'Clear Glass', color: 0xbfefff, transparent: true, alpha: 0.4, hardness: 0.35, drop: 'block:glass' },
  [BLOCK.EMBERSTONE]: { key: 'emberstone', name: 'Emberstone', color: 0x5d211d, fleck: 0xff7438, hardness: 3.4, drop: 'block:emberstone', preferred: 'pickaxe', minTier: 2 },
  [BLOCK.ASH]: { key: 'ash', name: 'Ash Soil', color: 0x4c4443, hardness: 0.7, drop: 'block:ash', preferred: 'shovel' },
  [BLOCK.GLOWSHROOM]: { key: 'glowshroom', name: 'Glowcap', color: 0x62e0c1, transparent: true, alpha: 0.9, collidable: false, hardness: 0.1, drop: 'glowcap', emissive: true },
  [BLOCK.STARSTONE]: { key: 'starstone', name: 'Starstone', color: 0x665f91, fleck: 0xb8a5ff, hardness: 3.8, drop: 'block:starstone', preferred: 'pickaxe', minTier: 3 },
  [BLOCK.VOIDGLASS]: { key: 'voidglass', name: 'Voidglass', color: 0x221c3c, fleck: 0x9a6cff, transparent: true, alpha: 0.72, hardness: 4.6, drop: 'block:voidglass', preferred: 'pickaxe', minTier: 4 },
  [BLOCK.WORKBENCH]: { key: 'workbench', name: 'Assembly Bench', color: 0x9b6233, topColor: 0xd69b55, hardness: 1.8, drop: 'block:workbench', preferred: 'axe', station: 'bench' },
  [BLOCK.KILN]: { key: 'kiln', name: 'Stone Kiln', color: 0x575b5d, fleck: 0xffa43a, hardness: 3.2, drop: 'block:kiln', preferred: 'pickaxe', minTier: 1, station: 'kiln' },
  [BLOCK.EMBER_PORTAL]: { key: 'ember_portal', name: 'Ember Gate', color: 0xff5a32, transparent: true, alpha: 0.75, collidable: false, hardness: 9999, drop: null, portal: 'ember', emissive: true },
  [BLOCK.STAR_PORTAL]: { key: 'star_portal', name: 'Astral Gate', color: 0x9075ff, transparent: true, alpha: 0.75, collidable: false, hardness: 9999, drop: null, portal: 'star', emissive: true },
  [BLOCK.TORCH]: { key: 'torch', name: 'Glow Torch', color: 0xffd45c, transparent: true, alpha: 0.95, collidable: false, hardness: 0.1, drop: 'block:torch', emissive: true },
  [BLOCK.CROP]: { key: 'crop', name: 'Grain Sprout', color: 0xa8bd45, transparent: true, alpha: 0.9, collidable: false, hardness: 0.1, drop: 'grain' },
  [BLOCK.SNOW]: { key: 'snow', name: 'Frost Soil', color: 0xe5eef4, sideColor: 0x8293a0, hardness: 0.55, drop: 'block:snow', preferred: 'shovel' },
  [BLOCK.BASALT]: { key: 'basalt', name: 'Basalt', color: 0x343034, hardness: 3.5, drop: 'block:basalt', preferred: 'pickaxe', minTier: 2 },
  [BLOCK.LAVA]: { key: 'lava', name: 'Magma', color: 0xff4d16, transparent: true, alpha: 0.78, collidable: false, hardness: 9999, drop: null, fluid: true, damaging: true, emissive: true },
  [BLOCK.CLOUDSTONE]: { key: 'cloudstone', name: 'Cloudstone', color: 0xd8d8ec, fleck: 0xaaa4d5, hardness: 2.2, drop: 'block:cloudstone', preferred: 'pickaxe', minTier: 2 }
};

export const TOOL_TIERS = Object.freeze({
  hand: 0,
  wood: 1,
  stone: 2,
  iron: 3,
  crystal: 4
});

export const ITEMS = {
  'block:turf': { name: 'Turf Block', icon: '🟩', blockId: BLOCK.TURF, color: '#5f9d45' },
  'block:loam': { name: 'Loam', icon: '🟫', blockId: BLOCK.LOAM, color: '#795638' },
  'block:stone': { name: 'Stone', icon: '⬜', blockId: BLOCK.STONE, color: '#74797c' },
  'block:log': { name: 'Timber Log', icon: '🪵', blockId: BLOCK.LOG, color: '#7b4d2a' },
  'block:leaves': { name: 'Leaf Cluster', icon: '🍃', blockId: BLOCK.LEAVES, color: '#3f7d3c' },
  'block:sand': { name: 'Sun Sand', icon: '🟨', blockId: BLOCK.SAND, color: '#d8c17a' },
  'block:planks': { name: 'Timber Boards', icon: '🟧', blockId: BLOCK.PLANKS, color: '#b67e43' },
  'block:brick': { name: 'Stone Brick', icon: '🧱', blockId: BLOCK.BRICK, color: '#8a8d8f' },
  'block:glass': { name: 'Clear Glass', icon: '🔷', blockId: BLOCK.GLASS, color: '#bfefff' },
  'block:emberstone': { name: 'Emberstone', icon: '🟥', blockId: BLOCK.EMBERSTONE, color: '#5d211d' },
  'block:ash': { name: 'Ash Soil', icon: '⬛', blockId: BLOCK.ASH, color: '#4c4443' },
  'block:starstone': { name: 'Starstone', icon: '🟪', blockId: BLOCK.STARSTONE, color: '#665f91' },
  'block:voidglass': { name: 'Voidglass', icon: '🔮', blockId: BLOCK.VOIDGLASS, color: '#221c3c' },
  'block:workbench': { name: 'Assembly Bench', icon: '🛠️', blockId: BLOCK.WORKBENCH, color: '#9b6233' },
  'block:kiln': { name: 'Stone Kiln', icon: '🏭', blockId: BLOCK.KILN, color: '#575b5d' },
  'block:torch': { name: 'Glow Torch', icon: '🔥', blockId: BLOCK.TORCH, color: '#ffd45c' },
  'block:snow': { name: 'Frost Soil', icon: '❄️', blockId: BLOCK.SNOW, color: '#e5eef4' },
  'block:basalt': { name: 'Basalt', icon: '◼️', blockId: BLOCK.BASALT, color: '#343034' },
  'block:cloudstone': { name: 'Cloudstone', icon: '☁️', blockId: BLOCK.CLOUDSTONE, color: '#d8d8ec' },

  stick: { name: 'Wooden Rod', icon: '🪄', color: '#b98552' },
  fiber: { name: 'Plant Fiber', icon: '🌿', color: '#6fa34a' },
  coal: { name: 'Cinder Chunk', icon: '⚫', color: '#25272a' },
  copper_ore: { name: 'Copper Ore', icon: '🟠', color: '#c77c4e' },
  copper_ingot: { name: 'Copper Ingot', icon: '🥉', color: '#d78750' },
  iron_ore: { name: 'Iron Ore', icon: '🪨', color: '#c8ad8f' },
  iron_ingot: { name: 'Iron Ingot', icon: '🔩', color: '#c9d2d8' },
  crystal: { name: 'Aether Crystal', icon: '💎', color: '#6ff1ff' },
  glowcap: { name: 'Glowcap', icon: '🍄', color: '#62e0c1', food: 3 },
  raw_meat: { name: 'Raw Grazer Meat', icon: '🥩', color: '#bf5f57', food: 2 },
  cooked_meat: { name: 'Roasted Grazer Meat', icon: '🍖', color: '#8b4d2f', food: 8 },
  grain: { name: 'Grain', icon: '🌾', color: '#d7bb52' },
  trail_bread: { name: 'Trail Bread', icon: '🥖', color: '#d7a65f', food: 6 },
  dark_essence: { name: 'Night Essence', icon: '🌑', color: '#59417f' },
  ember_shard: { name: 'Ember Shard', icon: '🔸', color: '#ff6f32' },
  star_fragment: { name: 'Star Fragment', icon: '✨', color: '#bda7ff' },
  ember_key: { name: 'Ember Sigil', icon: '🗝️', color: '#ff7046', key: 'ember' },
  star_key: { name: 'Astral Sigil', icon: '🗝️', color: '#9c86ff', key: 'star' },

  wood_pickaxe: { name: 'Timber Pick', icon: '⛏️', tool: 'pickaxe', tier: 1, speed: 2.1, damage: 2 },
  wood_axe: { name: 'Timber Axe', icon: '🪓', tool: 'axe', tier: 1, speed: 2.2, damage: 3 },
  wood_shovel: { name: 'Timber Spade', icon: '🥄', tool: 'shovel', tier: 1, speed: 2.4, damage: 2 },
  wood_sword: { name: 'Timber Blade', icon: '🗡️', tool: 'sword', tier: 1, speed: 1.0, damage: 4 },

  stone_pickaxe: { name: 'Stone Pick', icon: '⛏️', tool: 'pickaxe', tier: 2, speed: 3.6, damage: 3 },
  stone_axe: { name: 'Stone Axe', icon: '🪓', tool: 'axe', tier: 2, speed: 3.8, damage: 4 },
  stone_shovel: { name: 'Stone Spade', icon: '🥄', tool: 'shovel', tier: 2, speed: 4.0, damage: 3 },
  stone_sword: { name: 'Stone Blade', icon: '🗡️', tool: 'sword', tier: 2, speed: 1.0, damage: 5 },

  iron_pickaxe: { name: 'Iron Pick', icon: '⛏️', tool: 'pickaxe', tier: 3, speed: 5.4, damage: 4 },
  iron_axe: { name: 'Iron Axe', icon: '🪓', tool: 'axe', tier: 3, speed: 5.8, damage: 6 },
  iron_shovel: { name: 'Iron Spade', icon: '🥄', tool: 'shovel', tier: 3, speed: 6.0, damage: 4 },
  iron_sword: { name: 'Iron Blade', icon: '🗡️', tool: 'sword', tier: 3, speed: 1.0, damage: 7 },

  crystal_pickaxe: { name: 'Crystal Pick', icon: '⛏️', tool: 'pickaxe', tier: 4, speed: 8.0, damage: 6 },
  crystal_axe: { name: 'Crystal Axe', icon: '🪓', tool: 'axe', tier: 4, speed: 8.3, damage: 8 },
  crystal_sword: { name: 'Crystal Blade', icon: '⚔️', tool: 'sword', tier: 4, speed: 1.0, damage: 10 }
};

export const RECIPES = [
  { id: 'boards', name: 'Saw Timber Boards', out: ['block:planks', 4], in: { 'block:log': 1 }, station: 'hand', category: 'materials' },
  { id: 'rods', name: 'Shape Wooden Rods', out: ['stick', 4], in: { 'block:planks': 2 }, station: 'hand', category: 'materials' },
  { id: 'bench', name: 'Assembly Bench', out: ['block:workbench', 1], in: { 'block:planks': 4 }, station: 'hand', category: 'stations' },
  { id: 'wood_pick', name: 'Timber Pick', out: ['wood_pickaxe', 1], in: { 'block:planks': 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'wood_axe', name: 'Timber Axe', out: ['wood_axe', 1], in: { 'block:planks': 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'wood_shovel', name: 'Timber Spade', out: ['wood_shovel', 1], in: { 'block:planks': 1, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'wood_sword', name: 'Timber Blade', out: ['wood_sword', 1], in: { 'block:planks': 2, stick: 1 }, station: 'bench', category: 'weapons' },
  { id: 'stone_brick', name: 'Cut Stone Bricks', out: ['block:brick', 4], in: { 'block:stone': 4 }, station: 'bench', category: 'building' },
  { id: 'stone_pick', name: 'Stone Pick', out: ['stone_pickaxe', 1], in: { 'block:stone': 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'stone_axe', name: 'Stone Axe', out: ['stone_axe', 1], in: { 'block:stone': 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'stone_shovel', name: 'Stone Spade', out: ['stone_shovel', 1], in: { 'block:stone': 1, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'stone_sword', name: 'Stone Blade', out: ['stone_sword', 1], in: { 'block:stone': 2, stick: 1 }, station: 'bench', category: 'weapons' },
  { id: 'kiln', name: 'Stone Kiln', out: ['block:kiln', 1], in: { 'block:stone': 8 }, station: 'bench', category: 'stations' },
  { id: 'torch', name: 'Glow Torches', out: ['block:torch', 4], in: { coal: 1, stick: 1 }, station: 'hand', category: 'utilities' },
  { id: 'glass', name: 'Fire Clear Glass', out: ['block:glass', 4], in: { 'block:sand': 4, coal: 1 }, station: 'kiln', category: 'building' },
  { id: 'copper', name: 'Smelt Copper', out: ['copper_ingot', 1], in: { copper_ore: 1, coal: 1 }, station: 'kiln', category: 'materials' },
  { id: 'iron', name: 'Smelt Iron', out: ['iron_ingot', 1], in: { iron_ore: 1, coal: 1 }, station: 'kiln', category: 'materials' },
  { id: 'cook_meat', name: 'Roast Grazer Meat', out: ['cooked_meat', 1], in: { raw_meat: 1, coal: 1 }, station: 'kiln', category: 'food' },
  { id: 'bread', name: 'Bake Trail Bread', out: ['trail_bread', 1], in: { grain: 3, coal: 1 }, station: 'kiln', category: 'food' },
  { id: 'iron_pick', name: 'Iron Pick', out: ['iron_pickaxe', 1], in: { iron_ingot: 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'iron_axe', name: 'Iron Axe', out: ['iron_axe', 1], in: { iron_ingot: 3, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'iron_shovel', name: 'Iron Spade', out: ['iron_shovel', 1], in: { iron_ingot: 1, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'iron_sword', name: 'Iron Blade', out: ['iron_sword', 1], in: { iron_ingot: 2, stick: 1 }, station: 'bench', category: 'weapons' },
  { id: 'ember_key', name: 'Ember Sigil', out: ['ember_key', 1], in: { iron_ingot: 2, 'block:glass': 2, coal: 2, dark_essence: 1 }, station: 'bench', category: 'realms' },
  { id: 'basalt', name: 'Fuse Basalt', out: ['block:basalt', 4], in: { 'block:emberstone': 4, coal: 1 }, station: 'kiln', category: 'building' },
  { id: 'star_key', name: 'Astral Sigil', out: ['star_key', 1], in: { crystal: 2, ember_shard: 2, iron_ingot: 1 }, station: 'bench', category: 'realms' },
  { id: 'voidglass', name: 'Temper Voidglass', out: ['block:voidglass', 2], in: { 'block:starstone': 2, crystal: 1, coal: 1 }, station: 'kiln', category: 'building' },
  { id: 'crystal_pick', name: 'Crystal Pick', out: ['crystal_pickaxe', 1], in: { crystal: 3, iron_ingot: 2, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'crystal_axe', name: 'Crystal Axe', out: ['crystal_axe', 1], in: { crystal: 3, iron_ingot: 2, stick: 2 }, station: 'bench', category: 'tools' },
  { id: 'crystal_sword', name: 'Crystal Blade', out: ['crystal_sword', 1], in: { crystal: 2, iron_ingot: 2, stick: 1 }, station: 'bench', category: 'weapons' },
  { id: 'cloudstone', name: 'Bind Cloudstone', out: ['block:cloudstone', 4], in: { 'block:starstone': 2, fiber: 2, crystal: 1 }, station: 'bench', category: 'building' }
];

export const DIMENSIONS = {
  verdant: {
    name: 'Verdant Reach',
    subtitle: 'Forests, rivers, caverns, and long nights',
    sky: 0x78b9e8,
    fog: 0x9dc9df,
    ambient: 0xbfd0df,
    sunlight: 0xfff1c6,
    gravity: 24,
    spawn: [0, 28, 0]
  },
  ember: {
    name: 'Emberdeep',
    subtitle: 'A vast volcanic cavern beneath a black ceiling',
    sky: 0x1a0908,
    fog: 0x4a1711,
    ambient: 0x6e2b22,
    sunlight: 0xff7a45,
    gravity: 22,
    spawn: [0, 18, 0]
  },
  astral: {
    name: 'Starfall Expanse',
    subtitle: 'Floating islands above an endless luminous void',
    sky: 0x100c2b,
    fog: 0x2c2554,
    ambient: 0x7669b3,
    sunlight: 0xb8c9ff,
    gravity: 15,
    spawn: [0, 32, 0]
  }
};

export function itemName(id) {
  return ITEMS[id]?.name ?? id;
}

export function stationLabel(station) {
  return ({ hand: 'Anywhere', bench: 'Near Assembly Bench', kiln: 'Near Stone Kiln' })[station] ?? station;
}

export function canCraft(recipe, inventory, stationAvailable = () => true) {
  if (!stationAvailable(recipe.station)) return false;
  return Object.entries(recipe.in).every(([id, count]) => (inventory[id] ?? 0) >= count);
}

export function craftRecipe(recipe, inventory) {
  if (!Object.entries(recipe.in).every(([id, count]) => (inventory[id] ?? 0) >= count)) return false;
  for (const [id, count] of Object.entries(recipe.in)) inventory[id] -= count;
  const [outId, outCount] = recipe.out;
  inventory[outId] = (inventory[outId] ?? 0) + outCount;
  return true;
}
