# Blockwild: Realms

An original first-person voxel survival sandbox for modern desktop browsers.

Blockwild borrows the broad, non-exclusive idea of a block-based survival sandbox, but all names, visual styling, world lore, procedural art, recipes, creatures, dimensions, sounds, and source code in this project are original. No Minecraft textures, models, audio, code, logos, or copied UI assets are included.

## Play

```bash
npm install
npm run dev
```

Open the local address shown by Vite. For a production build:

```bash
npm run build
npm run preview
```

The game uses pointer lock and is designed for keyboard and mouse.

## Main systems

- Seeded procedural voxel terrain with streaming chunk meshes
- Mining, block placement, collision, jumping, sprinting, and creative flight
- Survival vitality, energy, food, damage, death, and respawning
- Day/night cycle with hostile night creatures
- Six creature types with passive and hostile behavior
- Inventory, nine-slot hotbar, pickups, and 31 progression recipes
- Hand, Assembly Bench, and Stone Kiln crafting tiers
- Tool classes and four material tiers
- Three original dimensions:
  - **Verdant Reach** — forests, rivers, caves, ores, weathered hills
  - **Emberdeep** — volcanic caverns, magma, glowcaps, hostile Emberlings
  - **Starfall Expanse** — low-gravity floating islands and void creatures
- Realm-gate progression with craftable sigils
- Survival and creative modes
- Local autosave, continue, and save export
- Responsive HUD, recipe browser, guide, pause, loading, victory, and error feedback
- Procedurally synthesized sound effects; no external audio files

## Controls

| Input | Action |
|---|---|
| W A S D | Move |
| Mouse | Look |
| Space | Jump / fly up |
| Shift | Sprint / fly down |
| Hold left mouse | Mine |
| Left mouse on creature | Attack |
| Right mouse | Place selected block or eat selected food |
| 1–9 / mouse wheel | Select hotbar slot |
| E | Inventory and crafting |
| F | Use a nearby realm gate |
| Esc | Pause / release pointer |

## Progression

1. Gather timber and craft boards.
2. Make and place an Assembly Bench.
3. Craft a pick, mine stone, and build a Stone Kiln.
4. Smelt iron, defeat a Night Shade, and forge an Ember Sigil.
5. Enter Emberdeep, gather Aether Crystal and Ember Shards.
6. Forge an Astral Sigil and reach Starfall Expanse.

## Notes

This is a substantial single-player browser prototype, not a reimplementation of every feature accumulated by a commercial game over many years. It intentionally focuses on a complete, playable survival/building loop and original content. Multiplayer, redstone-style automation, villages, enchanting, brewing, and hundreds of specialty blocks are outside this version.

World saves use browser `localStorage`. The pause menu can export a JSON backup.

## Verification

Run:

```bash
npm test
npm run build
```

## License

Code is provided under the MIT License. The title, original game names, original written lore, and original visual identity remain project-specific creative material.
